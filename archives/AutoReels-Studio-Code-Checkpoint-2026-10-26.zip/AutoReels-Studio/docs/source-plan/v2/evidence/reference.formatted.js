"use strict";
const $ = (s, r = document) => r.querySelector(s),
  $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (v) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const icons = {
  grid: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
  workflow: "M4 4h6v5H4z M14 15h6v5h-6z M14 4h6v5h-6z M7 9v8h7 M10 6h4",
  phone:
    "M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z M10 18h4",
  list: "M8 5h13 M8 12h13 M8 19h13 M3 5h.1 M3 12h.1 M3 19h.1",
  calendar:
    "M5 5h14a2 2 0 0 1 2 2v13H3V7a2 2 0 0 1 2-2z M7 3v4 M17 3v4 M3 10h18",
  history: "M3 11a9 9 0 1 1 2 7 M3 4v7h7 M12 7v6l4 2",
  settings:
    "M9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6",
  help: "M9 8a3 3 0 1 1 5 2c-2 1-2 2-2 3 M12 17h.1 M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20",
  sun: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v2 M12 20v2 M2 12h2 M20 12h2 M5 5l1 1 M18 18l1 1 M5 19l1-1 M18 6l1-1",
  bell: "M6 9a6 6 0 0 1 12 0v6l2 3H4l2-3z M10 21h4",
  search: "M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14 M15 15l6 6",
  plus: "M12 5v14 M5 12h14",
  play: "M7 4l14 8-14 8z",
  stop: "M5 5h14v14H5z",
  pause: "M8 4v16 M16 4v16",
  save: "M4 3h13l4 4v14H3V3z M7 3v6h10V3 M7 21v-8h10v8",
  more: "M5 12h.1 M12 12h.1 M19 12h.1",
  copy: "M8 8h13v13H8z M16 8V3H3v13h5",
  trash: "M3 6h18 M9 3h6 M6 6l1 15h10l1-15 M10 10v7 M14 10v7",
  edit: "M4 16L16 4l4 4L8 20H4z M14 6l4 4",
  chevron: "M9 5l7 7-7 7",
  down: "M5 9l7 7 7-7",
  undo: "M8 4L3 9l5 5 M3 9h11a7 7 0 0 1 7 7",
  redo: "M16 4l5 5-5 5 M21 9H10a7 7 0 0 0-7 7",
  fit: "M8 3H3v5 M16 3h5v5 M3 16v5h5 M21 16v5h-5",
  zoom: "M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14 M15 15l6 6 M7 10h6 M10 7v6",
  minus: "M5 12h14",
  link: "M10 14l4-4 M8 16l-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0 M16 8l2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0",
  branch: "M6 3v12a4 4 0 0 0 4 4h8 M6 9h7a4 4 0 0 0 4-4V3 M15 16l3 3-3 3",
  clock: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20 M12 6v6l4 3",
  tap: "M9 12V5a2 2 0 0 1 4 0v7 M13 9h3l4 3-2 8H9l-5-6 2-2 3 3",
  swipe: "M3 12h18 M7 8l-4 4 4 4 M17 8l4 4-4 4",
  text: "M4 5h16 M12 5v15 M8 20h8",
  image: "M3 3h18v18H3z M3 17l6-6 4 4 3-3 5 5 M16 7h.1",
  folder: "M3 5h7l2 3h9v12H3z",
  upload: "M12 16V3 M7 8l5-5 5 5 M3 15v6h18v-6",
  download: "M12 3v13 M7 11l5 5 5-5 M3 17v4h18v-4",
  check: "M5 12l4 4L20 5",
  close: "M5 5l14 14 M19 5L5 19",
  refresh:
    "M20 7a9 9 0 0 0-15-2L3 8 M3 3v5h5 M4 17a9 9 0 0 0 15 2l2-3 M21 21v-5h-5",
  eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6",
  code: "M8 5l-6 7 6 7 M16 5l6 7-6 7 M14 3l-4 18",
  box: "M3 6l9-4 9 4v12l-9 4-9-4z M3 6l9 5 9-5 M12 11v11",
  external: "M14 3h7v7 M21 3L10 14 M10 3H3v18h18v-7",
  home: "M3 10l9-8 9 8v11h-6v-7H9v7H3z",
  back: "M19 12H4 M10 5l-7 7 7 7",
  account: "M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M4 21v-3a8 6 0 0 1 16 0v3",
  comment: "M3 3h18v14H9l-6 4z",
  video: "M3 5h12v14H3z M15 10l6-4v12l-6-4",
  layout: "M3 3h18v18H3z M8 3v18 M8 15h13",
  align: "M4 3v18 M8 6h12 M8 12h8 M8 18h12",
  lock: "M6 10h12v11H6z M8 10V6a4 4 0 0 1 8 0v4",
  flag: "M5 22V3h14l-3 5 3 5H5",
  mouse: "M12 2a6 6 0 0 1 6 6v8a6 6 0 0 1-12 0V8a6 6 0 0 1 6-6 M12 3v6",
  network: "M12 4v7 M4 20v-5h16v5 M12 15v5 M8 2h8v5H8z",
  monitor: "M3 3h18v14H3z M12 17v4 M7 21h10",
  filter: "M3 4h18l-7 8v7l-4 2v-9z",
  step: "M6 4l11 8-11 8z M20 4v16",
  bug: "M8 8h8v9a4 4 0 0 1-8 0z M9 8V5h6v3 M3 10h5 M16 10h5 M3 16h5 M16 16h5",
  cpu: "M6 6h12v12H6z M9 9h6v6H9z M9 2v4 M15 2v4 M9 18v4 M15 18v4 M2 9h4 M18 9h4",
  hand: "M8 11V5 M12 11V3 M16 11V5 M20 13V8 M8 9a2 2 0 0 0-4 0v7l5 6h8l3-5v-4",
  table: "M3 4h18v16H3z M3 9h18 M8 9v11 M15 9v11",
};
function ic(n) {
  return `<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[n] || icons.box}"/></svg>`;
}
function hydrate() {
  $$("[data-icon]").forEach((e) => {
    e.innerHTML = ic(e.dataset.icon);
    e.removeAttribute("data-icon");
  });
}
function btn(a, n, t, cl = "") {
  return `<button data-action="${a}" class="${cl}" title="${esc(t)}">${n ? ic(n) : ""}${cl.includes("icon") ? "" : esc(t)}</button>`;
}
function toast(m) {
  let e = document.createElement("div");
  e.className = "toast";
  e.textContent = m;
  $("#toasts").append(e);
  setTimeout(() => e.remove(), 4000);
}
const apps = [
  {
    id: "fb",
    name: "Facebook",
    pkg: "com.facebook.katana",
    logo: "f",
    cls: "",
  },
  {
    id: "lite",
    name: "Facebook Lite",
    pkg: "com.facebook.lite",
    logo: "f",
    cls: "lite",
  },
  {
    id: "ig",
    name: "Instagram",
    pkg: "com.instagram.android",
    logo: "◎",
    cls: "ig",
  },
  {
    id: "tt",
    name: "TikTok",
    pkg: "com.zhiliaoapp.musically",
    logo: "♪",
    cls: "tt",
  },
  {
    id: "th",
    name: "Threads",
    pkg: "com.instagram.barcelona",
    logo: "@",
    cls: "th",
  },
];
const catalog = [
  ["start", "Bắt đầu", "play", "Luồng điều khiển", "#129c7c"],
  ["end", "Kết thúc", "flag", "Luồng điều khiển", "#129c7c"],
  ["condition", "If / Else", "branch", "Luồng điều khiển", "#c18a28"],
  ["loop", "Vòng lặp giới hạn", "refresh", "Luồng điều khiển", "#c18a28"],
  ["break", "Thoát vòng lặp", "stop", "Luồng điều khiển", "#c18a28"],
  ["continue", "Lượt tiếp theo", "step", "Luồng điều khiển", "#c18a28"],
  ["subflow", "Quy trình con", "box", "Luồng điều khiển", "#7862d6"],
  ["launch", "Mở ứng dụng", "external", "Ứng dụng & hệ thống", "#5b78cc"],
  [
    "installed",
    "Kiểm tra đã cài app",
    "check",
    "Ứng dụng & hệ thống",
    "#5b78cc",
  ],
  [
    "current",
    "Kiểm tra app hiện tại",
    "phone",
    "Ứng dụng & hệ thống",
    "#5b78cc",
  ],
  [
    "closeapp",
    "Đóng / mở lại app",
    "refresh",
    "Ứng dụng & hệ thống",
    "#5b78cc",
  ],
  ["back", "Back / Home / Recent", "back", "Ứng dụng & hệ thống", "#5b78cc"],
  ["tap", "Bấm phần tử", "tap", "Thao tác điện thoại", "#5c83d5"],
  ["doubletap", "Bấm đúp", "tap", "Thao tác điện thoại", "#5c83d5"],
  ["hold", "Nhấn giữ", "hand", "Thao tác điện thoại", "#5c83d5"],
  ["drag", "Kéo thả", "mouse", "Thao tác điện thoại", "#5c83d5"],
  ["swipe", "Vuốt màn hình", "swipe", "Thao tác điện thoại", "#5c83d5"],
  ["scroll", "Cuộn tới phần tử", "swipe", "Thao tác điện thoại", "#5c83d5"],
  ["pinch", "Chụm / mở hai ngón", "zoom", "Thao tác điện thoại", "#5c83d5"],
  ["type", "Nhập văn bản", "text", "Thao tác điện thoại", "#5c83d5"],
  ["clear", "Xóa nội dung ô nhập", "close", "Thao tác điện thoại", "#5c83d5"],
  [
    "keyboard",
    "Ẩn / thao tác bàn phím",
    "table",
    "Thao tác điện thoại",
    "#5c83d5",
  ],
  ["find", "Tìm XPath / thuộc tính", "search", "Nhận diện & chờ", "#399c92"],
  ["image", "Tìm ảnh mẫu", "image", "Nhận diện & chờ", "#399c92"],
  ["ocr", "Đọc chữ OCR", "text", "Nhận diện & chờ", "#399c92"],
  ["read", "Đọc thuộc tính / văn bản", "eye", "Nhận diện & chờ", "#399c92"],
  ["wait", "Chờ thời gian / ngẫu nhiên", "clock", "Nhận diện & chờ", "#399c92"],
  ["waitfor", "Chờ điều kiện", "clock", "Nhận diện & chờ", "#399c92"],
  ["screenshot", "Chụp màn hình", "image", "Nhận diện & chờ", "#399c92"],
  ["setvar", "Gán / biến đổi biến", "code", "Dữ liệu & nội dung", "#a06eae"],
  ["row", "Đọc dòng công việc", "table", "Dữ liệu & nội dung", "#a06eae"],
  [
    "stage",
    "Chuyển nội dung sang máy",
    "upload",
    "Dữ liệu & nội dung",
    "#a06eae",
  ],
  ["index", "Chờ MediaStore", "refresh", "Dữ liệu & nội dung", "#a06eae"],
  [
    "selectmedia",
    "Chọn đúng nội dung",
    "video",
    "Dữ liệu & nội dung",
    "#a06eae",
  ],
  [
    "cleanup",
    "Xóa tệp staging đã sở hữu",
    "trash",
    "Dữ liệu & nội dung",
    "#a06eae",
  ],
  [
    "transaction",
    "Ghi ý định gửi / đăng",
    "lock",
    "Giao dịch & kết quả",
    "#d48363",
  ],
  ["verify", "Xác minh kết quả", "check", "Giao dịch & kết quả", "#d48363"],
  [
    "output",
    "Ghi dữ liệu đầu ra",
    "download",
    "Giao dịch & kết quả",
    "#d48363",
  ],
  ["review", "Dừng để kiểm tra", "flag", "Giao dịch & kết quả", "#d48363"],
  ["log", "Ghi nhật ký", "list", "Giao dịch & kết quả", "#d48363"],
];
let seq = 100;
const uid = (p) => p + ++seq;
const clone = (o) => JSON.parse(JSON.stringify(o));
function node(id, type, name, x, y, extra = {}) {
  return {
    id,
    type,
    name,
    x,
    y,
    selector: "",
    method: "XPath / thuộc tính",
    value: "",
    timeout: 15000,
    retries: extra.effect ? 0 : 1,
    delayMin: 700,
    delayMax: 1800,
    description: "",
    ...extra,
  };
}
function edge(a, b, port = "next") {
  return { id: uid("e"), a, b, port };
}
function mainGraph(app = "fb") {
  let ns = [
    node("n1", "start", "Nhận dòng công việc", 40, 55, {
      description: "row.video · caption · hashtag",
    }),
    node("n2", "stage", "Chuyển đúng video", 285, 55, {
      value: "{{row.video}}",
      description: "PC → staging riêng của lượt chạy",
    }),
    node("n3", "launch", "Mở " + apps.find((a) => a.id === app).name, 530, 55, {
      description: apps.find((a) => a.id === app).pkg,
    }),
    node("n4", "subflow", "Đảm bảo đúng account", 775, 55, {
      sub: "account",
      description: "Kiểm tra → đổi nếu sai → xác minh",
    }),
    node(
      "n5",
      "subflow",
      app === "fb" || app === "lite"
        ? "Đảm bảo đúng fanpage"
        : "Xác minh đúng hồ sơ",
      775,
      235,
      { sub: "page", description: "target.id · không chọn theo tên trùng" },
    ),
    node("n6", "subflow", "Tạo & điền bài video", 530, 235, {
      sub: "compose",
      description: "Chọn video · caption · hashtag",
    }),
    node("n7", "transaction", "Ghi POST_INTENT", 285, 235, {
      description: "Lưu bền trước thao tác Đăng",
    }),
    node("n8", "tap", "Bấm Đăng một lần", 40, 235, {
      selector: '//*[@content-desc="Đăng"]',
      effect: "publish",
      description: "Tác động thật · không retry mù",
    }),
    node("n9", "verify", "Đã đăng thành công?", 40, 420, {
      description: "Khớp bài vừa đăng · trả post.id",
    }),
    node("n10", "condition", "Có bình luận?", 285, 420, {
      value: "row.comments.length > 0",
      description: "Dùng bình luận của dòng hiện tại",
    }),
    node("n11", "subflow", "Bình luận bài vừa đăng", 530, 420, {
      sub: "comment",
      description: "Gửi → xác minh · không đăng lại bài",
    }),
    node("n12", "cleanup", "Dọn staging của lượt", 775, 420, {
      description: "Chỉ tệp tool tạo · giữ nguồn PC",
    }),
    node("n13", "end", "Hoàn tất dòng", 775, 595, {
      description: "Lưu kết quả · chuyển lịch tiếp theo",
    }),
    node("n14", "review", "Giữ để đối soát", 40, 595, {
      description: "Chưa rõ kết quả → không đăng lại",
    }),
  ];
  let es = [
    edge("n1", "n2"),
    edge("n2", "n3"),
    edge("n3", "n4"),
    edge("n4", "n5"),
    edge("n5", "n6"),
    edge("n6", "n7"),
    edge("n7", "n8"),
    edge("n8", "n9"),
    edge("n9", "n10", "true"),
    edge("n9", "n14", "false"),
    edge("n9", "n14", "error"),
    edge("n10", "n11", "true"),
    edge("n10", "n12", "false"),
    edge("n10", "n14", "error"),
    edge("n11", "n12"),
    edge("n12", "n13"),
  ];
  return { nodes: ns, edges: es, groups: [] };
}
function makeSub(which) {
  let ns, es;
  if (which === "account" || which === "page") {
    let t = which === "account" ? "account" : "fanpage";
    ns = [
      node("s1", "start", "Nhận target." + t, 40, 70),
      node("s2", "read", "Đọc " + t + " hiện tại", 300, 70, {
        selector: '//*[@resource-id="identity"]',
      }),
      node("s3", "condition", "Đúng " + t + " yêu cầu?", 560, 70, {
        value: "current.id == input.targetId",
      }),
      node("s4", "tap", "Mở trình chuyển " + t, 560, 260, {
        selector: '//*[@content-desc="Chuyển trang cá nhân"]',
      }),
      node("s5", "scroll", "Tìm đúng " + t, 300, 260, {
        value: "{{input.targetId}}",
        description: "Tối đa 8 lượt cuộn · nhận diện duy nhất",
      }),
      node("s6", "tap", "Chọn & chờ chuyển", 40, 260),
      node("s7", "verify", "Xác minh lại danh tính", 40, 445),
      node("s8", "end", "Trả SUCCESS", 300, 445),
      node("s9", "review", "Trả IDENTITY_MISMATCH", 560, 445),
    ];
    es = [
      edge("s1", "s2"),
      edge("s2", "s3"),
      edge("s3", "s8", "true"),
      edge("s3", "s4", "false"),
      edge("s3", "s9", "error"),
      edge("s4", "s5"),
      edge("s5", "s6"),
      edge("s6", "s7"),
      edge("s7", "s8", "true"),
      edge("s7", "s9", "false"),
      edge("s7", "s9", "error"),
    ];
  } else if (which === "compose") {
    ns = [
      node("s1", "start", "Nhận dữ liệu dòng", 40, 70),
      node("s2", "tap", "Về Home · mở Tạo bài", 295, 70),
      node("s3", "tap", "Chọn nơi đăng video", 550, 70),
      node("s4", "index", "Chờ video được lập chỉ mục", 550, 250),
      node("s5", "selectmedia", "Chọn đúng video staging", 295, 250, {
        value: "{{row.video}}",
      }),
      node("s6", "tap", "Tiếp tục tới chi tiết", 40, 250),
      node("s7", "type", "Điền caption & hashtag", 40, 430, {
        value: "{{row.caption}}\n{{row.hashtags}}",
      }),
      node("s8", "verify", "Kiểm tra nội dung & target", 295, 430),
      node("s9", "end", "Trả READY_TO_PUBLISH", 550, 430),
      node("s10", "review", "Trả NEEDS_REVIEW", 295, 610),
    ];
    es = [
      edge("s1", "s2"),
      edge("s2", "s3"),
      edge("s3", "s4"),
      edge("s4", "s5"),
      edge("s5", "s6"),
      edge("s6", "s7"),
      edge("s7", "s8"),
      edge("s8", "s9", "true"),
      edge("s8", "s10", "false"),
      edge("s8", "s10", "error"),
    ];
  } else {
    ns = [
      node("s1", "start", "Nhận post.id & comments", 40, 70),
      node("s2", "tap", "Mở đúng bài vừa đăng", 295, 70, {
        value: "{{output.postId}}",
      }),
      node("s3", "tap", "Mở ô bình luận", 550, 70),
      node("s4", "type", "Điền bình luận hiện tại", 550, 250, {
        value: "{{row.comments[index]}}",
      }),
      node("s5", "transaction", "Ghi COMMENT_INTENT", 295, 250),
      node("s6", "tap", "Gửi bình luận một lần", 40, 250, {
        effect: "comment",
      }),
      node("s7", "verify", "Xác minh bình luận", 40, 430),
      node("s8", "end", "Trả COMMENTED", 295, 430),
      node("s9", "review", "Trả COMMENT_PENDING", 550, 430),
    ];
    es = [
      edge("s1", "s2"),
      edge("s2", "s3"),
      edge("s3", "s4"),
      edge("s4", "s5"),
      edge("s5", "s6"),
      edge("s6", "s7"),
      edge("s7", "s8", "true"),
      edge("s7", "s9", "false"),
      edge("s7", "s9", "error"),
    ];
  }
  return { nodes: ns, edges: es, groups: [] };
}
const devices = [
  {
    id: "d1",
    name: "Samsung A52",
    model: "SM-A525F",
    android: "13",
    serial: "R58M42EXAMPLE",
    online: true,
    enabled: true,
  },
  {
    id: "d2",
    name: "Xiaomi Note 12",
    model: "Redmi Note 12",
    android: "14",
    serial: "63B8EXAMPLE",
    online: true,
    enabled: true,
  },
  {
    id: "d3",
    name: "OPPO Reno8",
    model: "CPH2359",
    android: "13",
    serial: "OF96EXAMPLE",
    online: true,
    enabled: true,
  },
  {
    id: "d4",
    name: "Samsung A32",
    model: "SM-A325F",
    android: "12",
    serial: "RF8REXAMPLE",
    online: false,
    enabled: false,
  },
];
let state = {
  view: "inspector",
  app: "fb",
  device: "d1",
  workflow: "w1",
  target: "p1",
  account: "a1",
  libraryTab: "nodes",
  bottomTab: "properties",
  selected: [],
  edgeSelected: null,
  graphKey: "main",
  graphs: {
    main: mainGraph(),
    account: makeSub("account"),
    page: makeSub("page"),
    compose: makeSub("compose"),
    comment: makeSub("comment"),
  },
  zoom: 0.78,
  pan: { x: 30, y: 40 },
  snap: true,
  showMini: true,
  focus: false,
  inspect: true,
  phoneDock: "right",
  daily: 3,
  slots: ["08:00", "12:00", "19:00"],
  weekdays: [1, 2, 3, 4, 5, 6, 0],
  startDate: "2026-10-02",
  scheduleScope: "unscheduled",
  rows: [],
  contexts: {},
  logs: [],
  history: [],
  inputs: [
    { key: "video", type: "file", scope: "row", required: true },
    { key: "caption", type: "text", scope: "row", required: true },
    { key: "hashtags", type: "text", scope: "row", required: false },
    { key: "comments", type: "list", scope: "row", required: false },
    { key: "affiliate", type: "url", scope: "row", required: false },
    { key: "accountId", type: "identity", scope: "process", required: true },
    { key: "targetId", type: "identity", scope: "process", required: true },
  ],
  workflows: [
    {
      id: "w1",
      app: "fb",
      name: "Đăng video fanpage",
      version: 3,
      kind: "main",
    },
    {
      id: "w2",
      app: "fb",
      name: "Đăng ảnh bảng tin",
      version: 1,
      kind: "main",
    },
    {
      id: "w3",
      app: "fb",
      name: "Kiểm tra & chuyển account",
      version: 2,
      kind: "sub",
    },
    {
      id: "w4",
      app: "lite",
      name: "Đăng video · Facebook Lite",
      version: 1,
      kind: "main",
    },
    {
      id: "w5",
      app: "ig",
      name: "Đăng video / Reel Instagram",
      version: 2,
      kind: "main",
    },
    {
      id: "w6",
      app: "tt",
      name: "Đăng video TikTok",
      version: 1,
      kind: "main",
    },
    { id: "w7", app: "th", name: "Đăng bài Threads", version: 1, kind: "main" },
  ],
  settings: {
    theme: "light",
    overdue: "next",
    cleanup: "verified",
    timezone: "Asia/Ho_Chi_Minh",
    autoAppend: false,
    dedupe: true,
  },
  groups: [],
};
function demoRows() {
  return [
    "Buổi sáng ở Đà Lạt",
    "Một góc cà phê yên bình",
    "Đi chậm để thấy nhiều hơn",
    "Cuối tuần giữa thiên nhiên",
    "Những con đường xanh",
    "Hành trình ngày mới",
  ].map((c, i) => ({
    id: "content-" + (i + 1),
    file: `video_${String(i + 1).padStart(3, "0")}.mp4`,
    caption: c,
    hashtags: "#daily #lifestyle #vietnam",
    comments: i === 2 ? "" : "Bạn thích khoảnh khắc nào nhất?",
    affiliate: "",
    duration: ["00:34", "00:48", "01:12", "00:27", "00:41", "00:56"][i],
    path: "D:/NoiDung/GreenLiving/",
    scheduled: "",
    status: "Chưa lên lịch",
    checked: false,
    files: 1,
  }));
}
state.rows = demoRows();
let undoStack = [],
  redoStack = [],
  clipboard = null,
  connecting = null,
  runTimer = null,
  runState = null,
  currentPopup = null,
  dirty = false,
  localSaveTimer = null;
try {
  const saved = JSON.parse(
    localStorage.getItem("autoreels-studio-preview-v1") || "null",
  );
  if (saved && saved.graphs && saved.workflows) {
    state = { ...state, ...saved, selected: [], edgeSelected: null };
    seq = Math.max(
      100,
      ...Object.values(state.graphs).flatMap((g) =>
        [...g.nodes, ...g.edges].map(
          (n) => +(String(n.id).match(/\d+/) || [0])[0],
        ),
      ),
    );
    document.body.classList.toggle("dark", state.settings.theme === "dark");
  }
} catch {}
function graph() {
  return state.graphs[state.graphKey];
}
function wf() {
  return (
    state.workflows.find((w) => w.id === state.workflow) || state.workflows[0]
  );
}
function app() {
  return apps.find((a) => a.id === state.app) || apps[0];
}
function dev() {
  return (
    devices.find(
      (d) =>
        d.id ===
        (state.view === "inspector"
          ? state.testDevice || state.device
          : state.device),
    ) || devices[0]
  );
}
function appLogo(a = app()) {
  return `<span class="app-logo ${a.cls}">${a.logo}</span>`;
}
function selectedNode() {
  return graph().nodes.find((n) => n.id === state.selected[0]);
}
function save(mark = true) {
  if (mark) dirty = true;
  $("#save-state").textContent = "Đang lưu bản nháp…";
  clearTimeout(localSaveTimer);
  localSaveTimer = setTimeout(() => {
    try {
      rememberDefinition();
      localStorage.setItem(
        "autoreels-studio-preview-v1",
        JSON.stringify(state),
      );
      $("#save-state").textContent =
        "Đã lưu cục bộ · " +
        new Date().toLocaleTimeString("vi-VN", {
          hour: "2-digit",
          minute: "2-digit",
        });
      dirty = false;
    } catch {
      $("#save-state").textContent = "Không lưu được · hãy xuất JSON";
      toast("Bộ nhớ trình duyệt không khả dụng. Hãy xuất cấu hình JSON.");
    }
  }, 300);
}
function checkpoint() {
  undoStack.push(
    JSON.stringify({
      graphs: state.graphs,
      graphKey: state.graphKey,
      inputs: state.inputs,
    }),
  );
  if (undoStack.length > 60) undoStack.shift();
  redoStack = [];
}
function undo() {
  if (!undoStack.length) return toast("Chưa có thay đổi để hoàn tác");
  redoStack.push(
    JSON.stringify({
      graphs: state.graphs,
      graphKey: state.graphKey,
      inputs: state.inputs,
    }),
  );
  Object.assign(state, JSON.parse(undoStack.pop()));
  state.selected = [];
  render();
  save();
}
function redo() {
  if (!redoStack.length) return;
  undoStack.push(
    JSON.stringify({
      graphs: state.graphs,
      graphKey: state.graphKey,
      inputs: state.inputs,
    }),
  );
  Object.assign(state, JSON.parse(redoStack.pop()));
  render();
  save();
}
function log(m, level = "INFO") {
  state.logs.unshift({
    time: new Date().toLocaleTimeString("vi-VN"),
    level,
    message: m,
  });
  if (state.logs.length > 150) state.logs.pop();
  if (state.bottomTab === "logs") renderBottom();
}
function nav() {
  const items = [
    ["devices", "grid", "Điện thoại"],
    ["inspector", "workflow", "Inspector"],
    ["process", "list", "Tiến trình"],
    ["workflows", "box", "Thư viện"],
    ["schedule", "calendar", "Lịch đăng"],
    ["history", "history", "Lịch sử"],
  ];
  $("#nav").innerHTML = items
    .map(
      ([id, icon, t]) =>
        `<button data-view="${id}" class="${state.view === id ? "active" : ""}" title="${t}">${ic(icon)}${t}</button>`,
    )
    .join("");
  $("#page-name").textContent =
    items.find((i) => i[0] === state.view)?.[2] || "Inspector";
}
function render() {
  nav();
  if (state.view === "inspector") renderInspector();
  if (state.view === "devices") renderDevices();
  if (state.view === "process") renderProcess();
  if (state.view === "workflows") renderWorkflows();
  if (state.view === "schedule") renderSchedule();
  if (state.view === "history") renderHistory();
  hydrate();
}
function renderInspector() {
  $("#main").innerHTML =
    `<section class="inspector ${state.focus ? "focus" : ""}"><div class="workflow-top"><div class="row">${appLogo()}<div><div class="row"><span class="workflow-title">${esc(wf().name)}</span><span class="badge purple">Bản nháp · v${wf().version}</span></div><div class="workflow-sub">${esc(app().name)} <span style="margin:0 5px">/</span> ${state.graphKey === "main" ? "Quy trình chính" : esc(subName(state.graphKey))} · Dùng chung nhiều điện thoại</div></div></div><div class="row">${btn("workflow-menu", "more", "Quản lý workflow", "icon")}${btn("inputs", "table", "Đầu vào", "small hide-narrow")}${btn("validate", "check", "Kiểm tra", "small")}${btn("save", "save", "Lưu", "small")}${btn("run", "play", "Chạy mô phỏng", "primary small")}</div></div><div class="workspace ${state.phoneDock === "top" ? "top-dock" : ""}"><aside class="node-library"><div class="library-header"><div class="row between" style="margin-bottom:12px"><h3>Thư viện khối</h3><span class="badge">${catalog.length}</span></div><div class="search">${ic("search")}<input id="node-search" placeholder="Tìm node…" aria-label="Tìm node"></div></div><div class="tabs"><button data-lib="nodes" class="${state.libraryTab === "nodes" ? "active" : ""}">Node</button><button data-lib="subs" class="${state.libraryTab === "subs" ? "active" : ""}">Quy trình con</button></div><div id="library-list" class="library-scroll"></div><div class="library-foot">Kéo khối vào canvas hoặc bấm +<br><span class="tiny">${ic("mouse")} Chuột phải để xem thao tác</span></div></aside><section class="editor-main"><div class="canvas-tools"><button class="small ghost" data-action="parent" ${state.graphKey === "main" ? "disabled" : ""}>${ic("back")} Quy trình chính</button><span class="badge">${state.graphKey === "main" ? "MAIN" : esc(subName(state.graphKey))}</span><span class="grow"></span>${btn("undo", "undo", "Hoàn tác · Ctrl+Z", "icon")}${btn("redo", "redo", "Làm lại · Ctrl+Y", "icon")}<span class="divider"></span>${btn("layout", "layout", "Tự sắp xếp", "icon")}${btn("canvas-menu", "more", "Tùy chọn canvas", "icon")}</div><div class="canvas-wrap" id="canvas"><div class="canvas-hint">${state.graphKey === "main" ? "Đăng nội dung → xác minh → bình luận → dọn tệp" : "Quy trình con · đầu vào và đầu ra độc lập"}</div><div class="canvas-world" id="world"></div><div class="canvas-bottom">${btn("zoom-out", "minus", "Thu nhỏ", "icon")}<button data-action="fit" id="zoom-label">${Math.round(state.zoom * 100)}%</button>${btn("zoom-in", "plus", "Phóng to", "icon")}<span class="divider"></span>${btn("fit", "fit", "Vừa canvas · Ctrl+0", "icon")}${btn("snap", "grid", "Bật / tắt bắt lưới", state.snap ? "icon active" : "icon")}${btn("focus", "eye", "Chế độ tập trung", "icon")}</div><svg id="minimap" class="minimap" viewBox="0 0 130 86" title="Bấm để xem toàn bộ"></svg></div><div class="inspector-bottom"><div class="resize-y"></div><div class="tabs" id="bottom-tabs">${[
      ["properties", "Thuộc tính"],
      ["tree", "Cây UI"],
      ["variables", "Biến & dữ liệu"],
      ["logs", "Nhật ký"],
      ["debug", "Debug"],
    ]
      .map(
        ([k, t]) =>
          `<button data-bottom="${k}" class="${state.bottomTab === k ? "active" : ""}">${t}</button>`,
      )
      .join(
        "",
      )}<span class="grow"></span><button data-action="bottom-toggle" title="Thu gọn / mở rộng">${ic("down")}</button></div><div id="bottom-content" class="bottom-content"></div></div></section><div class="phone-resize"></div>${phonePane()}</div></section>`;
  renderLibrary();
  renderGraph();
  renderBottom();
  bindCanvas();
  bindResizers();
  $("#node-search").oninput = (e) => renderLibrary(e.target.value);
  if (state.phoneDock === "floating") floatPhone();
}
function subName(k) {
  return (
    {
      account: "Đảm bảo đúng account",
      page: "Đảm bảo đúng fanpage",
      compose: "Tạo & điền bài video",
      comment: "Bình luận bài vừa đăng",
    }[k] || k
  );
}
function renderLibrary(q = "") {
  const root = $("#library-list");
  if (!root) return;
  if (state.libraryTab === "subs") {
    root.innerHTML =
      Object.keys(state.graphs)
        .filter((k) => k !== "main" && !k.startsWith("wf:"))
        .map(
          (k) =>
            `<div class="lib-node" draggable="true" data-sub-add="${esc(k)}"><span class="node-symbol" style="background:var(--primarybg);color:var(--primary)">${ic("box")}</span><span>${esc(subName(k))}<br><small class="muted">${state.graphs[k].nodes.length} node · Đầu vào / đầu ra</small></span><span class="add">+</span></div>`,
        )
        .join("") +
      `<button data-action="new-sub" class="small" style="width:100%;margin-top:15px">${ic("plus")} Tạo quy trình con</button>`;
  } else {
    let group = "";
    root.innerHTML =
      catalog
        .filter((c) =>
          c[1].toLocaleLowerCase("vi").includes(q.toLocaleLowerCase("vi")),
        )
        .map((c) => {
          let h =
            c[3] !== group ? `<div class="group-label">${c[3]}</div>` : "";
          group = c[3];
          return (
            h +
            `<div class="lib-node" draggable="true" data-add="${c[0]}"><span class="node-symbol" style="background:${c[4]}14;color:${c[4]}">${ic(c[2])}</span><span>${c[1]}</span><span class="add">+</span></div>`
          );
        })
        .join("") || '<div class="empty">Không có node phù hợp</div>';
  }
  $$(".lib-node", root).forEach(
    (e) =>
      (e.ondragstart = (ev) =>
        ev.dataTransfer.setData(
          "text/plain",
          JSON.stringify({
            type: e.dataset.add || "subflow",
            sub: e.dataset.subAdd,
          }),
        )),
  );
}
function ports(n) {
  return [
    "condition",
    "verify",
    "find",
    "image",
    "installed",
    "current",
  ].includes(n.type)
    ? ["true", "false", "error"]
    : n.type === "end" || n.type === "review"
      ? []
      : ["next"];
}
function portY(n, p) {
  return (
    n.y +
    (ports(n).length > 1 ? { true: 31, false: 60, error: 89 }[p] || 31 : 35)
  );
}
function renderGraph() {
  const world = $("#world");
  if (!world) return;
  const g = graph();
  world.style.transform = `translate(${state.pan.x}px,${state.pan.y}px) scale(${state.zoom})`;
  let hiddenIds = new Set(
    (g.groups || [])
      .filter((gr) => gr.collapsed)
      .flatMap((gr) => gr.nodeIds || []),
  );
  let paths = g.edges
    .filter((e) => !hiddenIds.has(e.a) && !hiddenIds.has(e.b))
    .map((e) => {
      let a = g.nodes.find((n) => n.id === e.a),
        b = g.nodes.find((n) => n.id === e.b);
      if (!a || !b) return "";
      let x1 = a.x + (a.w || 190),
        y1 = portY(a, e.port),
        x2 = b.x,
        y2 = b.y + 35;
      let dx = Math.max(60, Math.abs(x2 - x1) * 0.45),
        d = e.reroute
          ? `M ${x1} ${y1} L ${e.reroute.x} ${e.reroute.y} L ${x2} ${y2}`
          : `M ${x1} ${y1} C ${x1 + dx} ${y1}, ${x2 - dx} ${y2}, ${x2} ${y2}`;
      return `<g data-edge="${e.id}"><path class="edge-hit" d="${d}"/><path class="edge ${e.port} ${state.edgeSelected === e.id ? "selected" : ""}" d="${d}" marker-end="url(#arrow-${e.port})"/>${e.reroute ? `<circle class="reroute-handle" data-reroute="${e.id}" cx="${e.reroute.x}" cy="${e.reroute.y}" r="6"/>` : ""}${e.port !== "next" ? `<text class="edge-label" x="${x1 + 16}" y="${y1 - 7}">${{ true: "Đúng", false: "Sai", error: "Lỗi" }[e.port]}</text>` : ""}</g>`;
    })
    .join("");
  world.innerHTML =
    (g.groups || [])
      .map(
        (gr) =>
          `<div class="node-group" style="left:${gr.x}px;top:${gr.y}px;width:${gr.collapsed ? 240 : gr.w}px;height:${gr.collapsed ? 65 : gr.h}px"><span>${esc(gr.name)} <button class="small" data-toggle-group="${gr.id}">${gr.collapsed ? "Mở nhóm" : "Thu gọn"}</button></span>${gr.collapsed ? `<div style="padding:20px;font-size:11px">${gr.nodeIds.length} node · nhóm trực quan</div>` : ""}</div>`,
      )
      .join("") +
    `<svg class="edges"><defs>${["next", "true", "false", "error"].map((p, i) => `<marker id="arrow-${p}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="${["#a8b3c7", "#30a38b", "#e8a253", "#df8290"][i]}"/></marker>`).join("")}</defs>${paths}<path id="wire-preview" class="edge selected"/></svg>` +
    g.nodes
      .filter((n) => !hiddenIds.has(n.id))
      .map((n) => {
        const c = catalog.find((c) => c[0] === n.type) || catalog[0],
          ps = ports(n);
        return `<div class="flow-node ${state.selected.includes(n.id) ? "selected" : ""} ${runState?.current === n.id ? "executing" : ""} ${n.breakpoint ? "breakpoint" : ""}" data-node="${n.id}" style="left:${n.x}px;top:${n.y}px;width:${n.w || 190}px;min-height:${n.h || 112}px"><i class="node-size" data-size="${n.id}" title="Kéo để thay đổi kích thước"></i><div class="node-head"><span class="node-symbol" style="background:${c[4]}16;color:${c[4]}">${ic(c[2])}</span><div><div class="node-name">${esc(n.name)}</div><div class="node-id">${esc(n.id)} · ${n.sub ? "QUY TRÌNH CON" : esc(c[1].toUpperCase())}</div></div></div><div class="node-detail" title="${esc(n.description || n.value || "Nhấp để cấu hình")}">${esc(n.description || n.value || "Nhấp để cấu hình")}</div><div class="node-actions">${[["node-run", "play", "Chạy thử node"], ["node-stop", "stop", "Dừng phiên thử"], ["node-edit", "settings", "Cấu hình"], ["node-copy", "copy", "Nhân bản"], ["node-delete", "trash", "Xóa node"], ...(n.type === "subflow" ? [["node-open", "external", "Mở quy trình con"]] : [["node-more", "more", "Thao tác khác"]])].map(([a, i, t]) => `<button data-action="${a}" data-id="${n.id}" title="${t}">${ic(i)}</button>`).join("")}</div>${n.type !== "start" ? `<i class="port in" data-port="in" data-node-id="${n.id}" title="Đầu vào"></i>` : ""}${ps.map((p) => `<i class="port out ${p}" data-port="${p}" data-node-id="${n.id}" title="${{ next: "Tiếp tục", true: "Đúng / tìm thấy", false: "Sai / không thấy", error: "Lỗi kiểm tra" }[p]}"></i>`).join("")}</div>`;
      })
      .join("");
  $("#zoom-label").textContent = Math.round(state.zoom * 100) + "%";
  renderMini();
}
function renderMini() {
  let e = $("#minimap");
  if (!e) return;
  e.style.display = state.showMini ? "block" : "none";
  let ns = graph().nodes,
    maxX = Math.max(1000, ...ns.map((n) => n.x + 210)),
    maxY = Math.max(700, ...ns.map((n) => n.y + 130));
  e.innerHTML = ns
    .map(
      (n) =>
        `<rect x="${(n.x / maxX) * 125}" y="${(n.y / maxY) * 80}" width="${(190 / maxX) * 125}" height="${(110 / maxY) * 80}" rx="2"/>`,
    )
    .join("");
  e.onclick = fit;
}
function fit() {
  const el = $("#canvas");
  if (!el) return;
  let ns = graph().nodes;
  if (!ns.length) return;
  let minX = Math.min(...ns.map((n) => n.x)),
    minY = Math.min(...ns.map((n) => n.y)),
    w = Math.max(...ns.map((n) => n.x + 210)) - minX,
    h = Math.max(...ns.map((n) => n.y + 135)) - minY;
  state.zoom = Math.min(
    1.2,
    Math.max(
      0.25,
      Math.min((el.clientWidth - 65) / w, (el.clientHeight - 80) / h),
    ),
  );
  state.pan = {
    x: (el.clientWidth - w * state.zoom) / 2 - minX * state.zoom,
    y: 35 - minY * state.zoom,
  };
  renderGraph();
}
function addNode(type, x, y, sub) {
  checkpoint();
  let c = catalog.find((c) => c[0] === type) || catalog[0];
  let n = node(
    uid("n"),
    type,
    sub ? subName(sub) : c[1],
    x ?? Math.max(20, (150 - state.pan.x) / state.zoom),
    y ?? Math.max(20, (120 - state.pan.y) / state.zoom),
    sub ? { sub } : {},
  );
  graph().nodes.push(n);
  state.selected = [n.id];
  renderGraph();
  renderBottom();
  save();
  return n;
}
function removeSelected() {
  if (!state.selected.length && !state.edgeSelected) return;
  checkpoint();
  graph().nodes = graph().nodes.filter((n) => !state.selected.includes(n.id));
  graph().edges = graph().edges.filter(
    (e) =>
      e.id !== state.edgeSelected &&
      !state.selected.includes(e.a) &&
      !state.selected.includes(e.b),
  );
  state.selected = [];
  state.edgeSelected = null;
  renderGraph();
  renderBottom();
  save();
  toast("Đã xóa. Ctrl+Z để hoàn tác; dùng Kiểm tra để xem đường còn thiếu.");
}
function duplicateSelected() {
  if (!state.selected.length) return;
  clipboard = {
    nodes: clone(graph().nodes.filter((n) => state.selected.includes(n.id))),
    edges: clone(
      graph().edges.filter(
        (e) => state.selected.includes(e.a) && state.selected.includes(e.b),
      ),
    ),
  };
  pasteNodes();
}
function pasteNodes() {
  if (!clipboard) return toast("Chưa có node trong bộ nhớ sao chép");
  checkpoint();
  let map = {};
  let ns = clipboard.nodes.map((n) => {
    let id = uid("n");
    map[n.id] = id;
    return { ...clone(n), id, x: n.x + 35, y: n.y + 35 };
  });
  graph().nodes.push(...ns);
  graph().edges.push(
    ...clipboard.edges.map((e) => ({
      ...e,
      id: uid("e"),
      a: map[e.a],
      b: map[e.b],
    })),
  );
  state.selected = ns.map((n) => n.id);
  renderGraph();
  renderBottom();
  save();
}
function renderBottom() {
  const el = $("#bottom-content");
  if (!el) return;
  $$("[data-bottom]").forEach((b) =>
    b.classList.toggle("active", b.dataset.bottom === state.bottomTab),
  );
  let n = selectedNode();
  if (state.bottomTab === "properties") {
    if (!n) {
      el.innerHTML = `<div class="row between"><div><h3>Thiết kế thao tác, dùng lại trên nhiều máy</h3><p class="muted smalltext" style="margin-top:6px">Chọn node để sửa. Kéo từ cổng phải sang cổng trái để nối nhánh.</p></div><span class="badge green">${graph().nodes.length} node · ${graph().edges.length} liên kết</span></div><div class="row wrap" style="margin-top:18px">${btn("inputs", "table", "Khai báo đầu vào", "small")}${btn("validate", "check", "Kiểm tra workflow", "small")}${btn("test-data", "bug", "Dữ liệu chạy thử", "small")}<span class="muted smalltext">${ic("phone")} Máy kiểm thử: ${esc(dev().name)}</span></div>`;
      return;
    }
    el.innerHTML = `<div class="row between" style="margin-bottom:10px"><div class="row"><strong>${esc(n.name)}</strong><span class="badge">${esc(n.id)}</span>${n.effect ? '<span class="badge amber">Thao tác gửi / đăng</span>' : ""}</div><div class="row">${btn("advanced-node", "settings", "Nâng cao", "small")}${n.type === "subflow" ? btn("open-selected-sub", "external", "Mở khối con", "small") : ""}</div></div><div class="form-grid"><div><label>Tên node</label><input data-prop="name" value="${esc(n.name)}"></div><div><label>Nhận diện mục tiêu</label><select data-prop="method">${["XPath / thuộc tính", "Ảnh mẫu", "OCR / văn bản", "Vị trí tương đối", "Tọa độ"].map((t) => `<option ${n.method === t ? "selected" : ""}>${t}</option>`).join("")}</select></div><div><label>Timeout (ms)</label><input type="number" min="100" data-prop="timeout" value="${n.timeout}"></div><div><label>${n.type === "condition" ? "Biểu thức điều kiện" : "Giá trị / dữ liệu ánh xạ"}</label><input data-prop="value" placeholder="{{row.caption}}" value="${esc(n.value)}"></div><div><label>Selector / tiêu chí <span class="help" title="Có thể chọn trực tiếp trên điện thoại mẫu">?</span></label><div class="row"><input data-prop="selector" placeholder="Chọn phần tử trên điện thoại" value="${esc(n.selector)}"><button class="icon" data-action="pick" title="Chọn phần tử">${ic("tap")}</button></div></div><div><label>Chờ ngẫu nhiên sau bước (ms)</label><div class="row"><input type="number" min="0" data-prop="delayMin" value="${n.delayMin}"><span>–</span><input type="number" min="0" data-prop="delayMax" value="${n.delayMax}"></div></div></div>`;
    $$("[data-prop]", el).forEach(
      (e) =>
        (e.onchange = () => {
          checkpoint();
          n[e.dataset.prop] =
            e.type === "number" ? Math.max(0, +e.value) : e.value;
          renderGraph();
          save();
        }),
    );
  } else if (state.bottomTab === "tree") {
    el.innerHTML = `<div class="row between"><span class="badge amber">Cây UI minh họa · snapshot mẫu</span>${btn("refresh-tree", "refresh", "Làm mới", "small")}</div><div class="tree"><button data-tree="android.widget.FrameLayout">▾ android.widget.FrameLayout · ${esc(app().pkg)}</button><button data-tree="android.view.ViewGroup" style="padding-left:22px">▾ android.view.ViewGroup · Home</button><button data-tree="create_post" style="padding-left:42px">↳ android.widget.Button · Tạo bài viết</button><button data-tree="profile_switcher" style="padding-left:42px">↳ android.widget.Button · Chuyển trang cá nhân</button><button data-tree="video_picker" style="padding-left:42px">↳ android.widget.Button · Ảnh / video</button></div>`;
  } else if (state.bottomTab === "variables") {
    el.innerHTML = `<div class="row between"><strong>Dữ liệu của lượt thử</strong>${btn("test-data", "edit", "Chỉnh dữ liệu thử", "small")}</div><div class="vars" style="margin-top:8px">input.accountId = "account-demo-a"<br>input.targetId = "green-living"<br>row.video = "${esc(state.rows[0]?.file || "Chưa chọn")}"<br>row.caption = "${esc(state.rows[0]?.caption || "")}"<br>output.postId = ${runState?.finished ? '"demo-post-id"' : "null"} <span class="muted">// Chỉ được gán sau xác minh</span></div>`;
  } else if (state.bottomTab === "logs") {
    el.innerHTML = state.logs.length
      ? state.logs
          .map(
            (l) =>
              `<div class="log-line"><time>${l.time}</time><span class="level">${l.level}</span><span>${esc(l.message)}</span></div>`,
          )
          .join("")
      : '<div class="empty">Chưa có nhật ký. Chạy mô phỏng để xem đường thực thi.</div>';
  } else {
    el.innerHTML = `<div class="row wrap">${btn("debug-step", "step", "Bước tiếp", "small")}${btn("debug-into", "external", "Vào khối con", "small")}${btn("parent", "back", "Ra khối cha", "small")}${btn("breakpoint", "flag", "Bật / tắt breakpoint", "small")}${btn("pause", "pause", "Tạm dừng", "small")}${btn("stop", "stop", "Dừng", "small danger")}</div><p class="muted smalltext" style="margin-top:12px">Chạy thử HTML chỉ tô sáng đường đi. Không thao tác điện thoại, không đăng bài.</p><div class="vars" style="margin-top:10px">Call stack: ${esc(wf().name)}${state.graphKey !== "main" ? " → " + esc(subName(state.graphKey)) : ""}<br>Trạng thái: ${runState?.paused ? "PAUSED" : runState && !runState.finished ? "RUNNING" : "IDLE"} · Node: ${esc(runState?.current || "—")}</div>`;
  }
}
function phonePane() {
  return `<aside class="phone-pane" id="phone-pane"><div class="phone-heading"><div class="row between"><span class="smalltext"><strong>Điện thoại kiểm thử</strong></span><span class="badge green"><i class="dot"></i> Mẫu</span></div><div class="row" style="margin-top:10px">${ic("phone")}<select id="test-device" style="flex:1;font-size:11px;padding:6px">${devices.map((d) => `<option value="${d.id}" ${(state.testDevice || state.device) === d.id ? "selected" : ""} ${!d.online ? "disabled" : ""}>${esc(d.name)}${!d.online ? " · Offline" : ""}</option>`).join("")}</select>${btn("device-info", "more", "Thông tin máy", "icon")}</div><div class="phone-toolbar">${btn("pick", "tap", "Chọn phần tử", state.inspect ? "icon active" : "icon")}${btn("phone-control", "mouse", "Điều khiển mẫu", !state.inspect ? "icon active" : "icon")}${btn("phone-refresh", "refresh", "Làm mới màn hình", "icon")}${btn("phone-fit", "fit", "Vừa khung điện thoại", "icon")}${btn("phone-dock", "layout", "Bố trí điện thoại", "icon")}${btn("phone-popup", "external", "Tách cửa sổ", "icon")}</div></div><div class="phone-stage"><div class="phone-device" id="phone-screen" title="Màn hình minh họa. Bấm để chọn phần tử mẫu.">${phoneScreen()}</div><div class="phone-caption">1080 × 2400 · Android ${dev().android} · Khung hình mẫu<br><span class="badge purple" style="margin-top:6px">${state.inspect ? "Chế độ chọn phần tử" : "Điều khiển minh họa"}</span></div><div class="phone-controls">${btn("phone-back", "back", "Back", "icon")}${btn("phone-home", "home", "Home", "icon")}${btn("phone-recent", "box", "Recent", "icon")}</div></div><div class="phone-footer"><div class="row between"><span>${ic("lock")} Chưa kết nối Android thật</span><span class="badge">PREVIEW</span></div><div class="row" style="margin-top:9px"><span>Zoom</span><input id="phone-zoom" type="range" min="70" max="150" value="100" style="flex:1"><span id="phone-zoom-value">100%</span></div></div></aside>`;
}
function phoneScreen() {
  let isIG = state.app === "ig";
  return `<div class="phone-status"><span>09:41</span><span>▮▮▮  ▰ 94</span></div><div class="phone-camera"></div><div class="fb-header" style="${isIG ? "color:#252733;font-style:italic;font-size:22px" : ""}">${isIG ? "Instagram" : state.app === "tt" ? "TikTok" : state.app === "th" ? "Threads" : "facebook"}<span style="font-size:17px;color:#293341">＋ ☰</span></div><div class="fb-nav">${["home", "video", "account", "bell", "list"].map(ic).join("")}</div><div class="fb-user"><div class="fb-avatar">GL</div><div class="fb-prompt">Bạn đang nghĩ gì?</div></div><div class="fb-post-options"><span style="color:#e96b73">● Trực tiếp</span><span style="color:#399765">▧ Ảnh / video</span><span style="color:#9a66bb">▣ Reel</span></div><div class="fb-stories"><div class="story"><span>Tạo tin</span></div><div class="story"><span>Green Living</span></div><div class="story"><span>Daily moments</span></div></div><div class="fb-user"><div class="fb-avatar">GL</div><div><strong>Green Living</strong><div style="font-size:8px;color:#8a95a5">Vừa xong · 🌐</div></div><span style="margin-left:auto">···</span></div><div class="fb-post-caption">Một chút bình yên cho ngày mới 🌿<br><span style="color:#287ac9">#greenliving #daily</span></div><div class="fb-landscape"></div><div class="fb-reactions"><span>♡ Thích</span><span>▢ Bình luận</span><span>↗ Chia sẻ</span></div><div class="phone-homebar"></div>${state.inspect ? '<div class="inspect-target"><span>Button · create_post</span></div>' : ""}`;
}
function bindResizers() {
  let x = $(".phone-resize");
  if (x)
    x.onpointerdown = (e) => {
      let start = e.clientX,
        w = $("#phone-pane").offsetWidth;
      const move = (ev) =>
        document.documentElement.style.setProperty(
          "--phonew",
          Math.max(270, Math.min(650, w + start - ev.clientX)) + "px",
        );
      window.addEventListener("pointermove", move);
      window.addEventListener(
        "pointerup",
        () => window.removeEventListener("pointermove", move),
        { once: true },
      );
    };
  let y = $(".resize-y");
  if (y)
    y.onpointerdown = (e) => {
      let start = e.clientY,
        h = $(".inspector-bottom").offsetHeight;
      const move = (ev) =>
        ($(".inspector-bottom").style.height =
          Math.max(110, Math.min(innerHeight * 0.65, h + start - ev.clientY)) +
          "px");
      window.addEventListener("pointermove", move);
      window.addEventListener(
        "pointerup",
        () => window.removeEventListener("pointermove", move),
        { once: true },
      );
    };
}
let spaceHeld = false;
function bindCanvas() {
  let canvas = $("#canvas");
  canvas.oncontextmenu = (e) => {
    e.preventDefault();
    let ne = e.target.closest("[data-node]"),
      ee = e.target.closest("[data-edge]");
    if (ne && !state.selected.includes(ne.dataset.node)) {
      state.selected = [ne.dataset.node];
      renderGraph();
      renderBottom();
    }
    if (ee) {
      state.edgeSelected = ee.dataset.edge;
      renderGraph();
    }
    showCanvasMenu(e.clientX, e.clientY, ne ? "node" : ee ? "edge" : "canvas");
  };
  canvas.ondragover = (e) => e.preventDefault();
  canvas.ondrop = (e) => {
    e.preventDefault();
    try {
      let d = JSON.parse(e.dataTransfer.getData("text/plain")),
        r = canvas.getBoundingClientRect();
      addNode(
        d.type,
        (e.clientX - r.left - state.pan.x) / state.zoom,
        (e.clientY - r.top - state.pan.y) / state.zoom,
        d.sub,
      );
    } catch {}
  };
  canvas.onwheel = (e) => {
    e.preventDefault();
    if (e.ctrlKey || e.metaKey) {
      let r = canvas.getBoundingClientRect(),
        mx = e.clientX - r.left,
        my = e.clientY - r.top,
        old = state.zoom;
      state.zoom = Math.min(
        1.8,
        Math.max(0.25, state.zoom * (e.deltaY > 0 ? 0.9 : 1.1)),
      );
      state.pan.x = mx - ((mx - state.pan.x) * state.zoom) / old;
      state.pan.y = my - ((my - state.pan.y) * state.zoom) / old;
    } else {
      state.pan.x -= e.deltaX;
      state.pan.y -= e.deltaY;
    }
    renderGraph();
  };
  canvas.onpointerdown = (e) => {
    if (
      e.button === 2 ||
      e.target.closest("button") ||
      e.target.closest(".minimap")
    )
      return;
    let port = e.target.closest("[data-port]"),
      ne = e.target.closest("[data-node]"),
      ee = e.target.closest("[data-edge]");
    if (port) {
      if (port.dataset.port === "in" && connecting) {
        connectNodes(connecting.a, port.dataset.nodeId, connecting.port);
        connecting = null;
        return;
      }
      if (port.dataset.port !== "in") {
        connecting = { a: port.dataset.nodeId, port: port.dataset.port };
        const move = (ev) => {
          let a = graph().nodes.find((n) => n.id === connecting?.a);
          if (!a) return;
          let r = canvas.getBoundingClientRect(),
            x = (ev.clientX - r.left - state.pan.x) / state.zoom,
            y = (ev.clientY - r.top - state.pan.y) / state.zoom;
          $("#wire-preview")?.setAttribute(
            "d",
            `M${a.x + 190} ${portY(a, connecting.port)} C${a.x + 250} ${portY(a, connecting.port)},${x - 70} ${y},${x} ${y}`,
          );
        };
        const up = (ev) => {
          window.removeEventListener("pointermove", move);
          let target = document
            .elementFromPoint(ev.clientX, ev.clientY)
            ?.closest('[data-port="in"]');
          if (target && connecting) {
            connectNodes(connecting.a, target.dataset.nodeId, connecting.port);
            connecting = null;
          } else toast("Chọn cổng vào của node đích để hoàn tất liên kết");
        };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up, { once: true });
        return;
      }
    }
    if (ee) {
      state.edgeSelected = ee.dataset.edge;
      state.selected = [];
      renderGraph();
      renderBottom();
      return;
    }
    if (ne && !spaceHeld && e.button !== 1) {
      state.edgeSelected = null;
      let id = ne.dataset.node;
      if (e.shiftKey) {
        state.selected = state.selected.includes(id)
          ? state.selected.filter((x) => x !== id)
          : [...state.selected, id];
      } else if (!state.selected.includes(id)) {
        state.selected = [id];
      }
      renderGraph();
      renderBottom();
      const start = { x: e.clientX, y: e.clientY },
        positions = graph()
          .nodes.filter((n) => state.selected.includes(n.id))
          .map((n) => ({ id: n.id, x: n.x, y: n.y }));
      let moved = false;
      const move = (ev) => {
        if (
          !moved &&
          Math.abs(ev.clientX - start.x) + Math.abs(ev.clientY - start.y) > 4
        ) {
          checkpoint();
          moved = true;
        }
        if (!moved) return;
        let cr = canvas.getBoundingClientRect();
        if (ev.clientX < cr.left + 24) state.pan.x += 7;
        if (ev.clientX > cr.right - 24) state.pan.x -= 7;
        if (ev.clientY < cr.top + 24) state.pan.y += 7;
        if (ev.clientY > cr.bottom - 24) state.pan.y -= 7;
        positions.forEach((p) => {
          let n = graph().nodes.find((n) => n.id === p.id),
            x = p.x + (ev.clientX - start.x) / state.zoom,
            y = p.y + (ev.clientY - start.y) / state.zoom;
          n.x = state.snap ? Math.round(x / 10) * 10 : x;
          n.y = state.snap ? Math.round(y / 10) * 10 : y;
        });
        renderGraph();
      };
      window.addEventListener("pointermove", move);
      window.addEventListener(
        "pointerup",
        () => {
          window.removeEventListener("pointermove", move);
          if (moved) save();
        },
        { once: true },
      );
      return;
    }
    if (e.shiftKey) {
      let r = canvas.getBoundingClientRect(),
        sx = e.clientX - r.left,
        sy = e.clientY - r.top;
      let m = document.createElement("div");
      m.className = "marquee";
      canvas.append(m);
      let end = { x: sx, y: sy };
      const move = (ev) => {
        end = { x: ev.clientX - r.left, y: ev.clientY - r.top };
        Object.assign(m.style, {
          left: Math.min(sx, end.x) + "px",
          top: Math.min(sy, end.y) + "px",
          width: Math.abs(end.x - sx) + "px",
          height: Math.abs(end.y - sy) + "px",
        });
      };
      window.addEventListener("pointermove", move);
      window.addEventListener(
        "pointerup",
        () => {
          window.removeEventListener("pointermove", move);
          m.remove();
          state.selected = graph()
            .nodes.filter((n) => {
              let x = n.x * state.zoom + state.pan.x,
                y = n.y * state.zoom + state.pan.y;
              return (
                x + 190 * state.zoom >= Math.min(sx, end.x) &&
                x <= Math.max(sx, end.x) &&
                y + 112 * state.zoom >= Math.min(sy, end.y) &&
                y <= Math.max(sy, end.y)
              );
            })
            .map((n) => n.id);
          renderGraph();
          renderBottom();
        },
        { once: true },
      );
      return;
    }
    state.selected = [];
    state.edgeSelected = null;
    renderBottom();
    let sx = e.clientX,
      sy = e.clientY,
      p = { ...state.pan };
    const move = (ev) => {
      state.pan = { x: p.x + ev.clientX - sx, y: p.y + ev.clientY - sy };
      renderGraph();
    };
    window.addEventListener("pointermove", move);
    window.addEventListener(
      "pointerup",
      () => window.removeEventListener("pointermove", move),
      { once: true },
    );
    renderGraph();
  };
  canvas.ondblclick = (e) => {
    let n = e.target.closest("[data-node]");
    if (n) {
      state.selected = [n.dataset.node];
      let data = selectedNode();
      if (data.type === "subflow") openSub(data.sub);
      else advancedNode();
    } else if (!e.target.closest("button")) addNodeMenu();
  };
}
function connectNodes(a, b, p) {
  if (a === b)
    return toast(
      "Không nối node vào chính nó. Dùng node vòng lặp có giới hạn.",
    );
  if (graph().edges.some((e) => e.a === a && e.port === p))
    return toast("Cổng này đã có dây. Xóa dây hiện tại trước khi nối lại.");
  if (graph().nodes.find((n) => n.id === b)?.type === "start")
    return toast("Node Bắt đầu không nhận dây vào");
  checkpoint();
  graph().edges.push(edge(a, b, p));
  renderGraph();
  save();
  toast("Đã nối " + p + " → " + b);
}
function renderDevices() {
  let online = devices.filter((d) => d.online).length;
  $("#main").innerHTML =
    `<div class="page"><div class="page-head"><div><div class="eyebrow">DEVICE WORKSPACE</div><h2>Dãy điện thoại</h2><p class="subtext">Chọn máy để thiết lập công việc hoặc mở Inspector.</p></div><div class="row">${btn("device-manager", "settings", "Quản lý thiết bị")}${btn("scan-devices", "refresh", "Làm mới", "primary")}</div></div><div class="metric-grid">${[
      ["Thiết bị mẫu", devices.length, "phone"],
      ["Đang kết nối", online, "network"],
      [
        "Tiến trình đã cấu hình",
        Object.keys(state.contexts).length + 1,
        "workflow",
      ],
      ["Nội dung trong cấu hình", state.rows.length, "video"],
    ]
      .map(
        ([t, n, i]) =>
          `<div class="card metric"><div class="row between"><span class="muted smalltext">${t}</span>${ic(i)}</div><div class="number">${n}</div><span class="tiny muted">Dữ liệu xem trước</span></div>`,
      )
      .join(
        "",
      )}</div><div class="toolbar"><div class="search" style="width:255px">${ic("search")}<input id="device-filter" placeholder="Tìm tên, model hoặc mã máy…"></div><span class="grow"></span><label class="row" style="margin:0">Kích thước <input id="device-size" type="range" min="170" max="320" value="205"></label>${btn("device-bulk", "more", "Thao tác nhóm", "icon")}</div><div class="device-grid" id="device-grid">${devices.map((d, i) => deviceCard(d, i)).join("")}</div><div class="notice" style="margin-top:20px">Bản HTML dùng ${devices.length} điện thoại mẫu. Bộ đếm lấy từ danh sách này; không đại diện thiết bị thực tế đang kết nối.</div></div>`;
  $("#device-filter").oninput = (e) => {
    $$(".device-card").forEach(
      (c) =>
        (c.style.display = c.textContent
          .toLowerCase()
          .includes(e.target.value.toLowerCase())
          ? ""
          : "none"),
    );
  };
  $("#device-size").oninput = (e) =>
    ($("#device-grid").style.gridTemplateColumns =
      `repeat(auto-fill,minmax(${e.target.value}px,1fr))`);
}
function deviceCard(d, i) {
  return `<div class="card device-card ${state.device === d.id ? "selected" : ""}" data-device-card="${d.id}" oncontextmenu="event.preventDefault();deviceContext(event,'${d.id}')"><div class="row between"><span class="badge ${d.online ? "green" : ""}">${d.online ? "Sẵn sàng · mẫu" : "Mất kết nối · mẫu"}</span><input type="checkbox" class="device-select" value="${d.id}" title="Chọn máy cho thao tác nhóm"></div><div class="device-thumb"><div class="mini-phone">facebook<div class="mini-line"></div><div class="mini-image"></div><div class="mini-line"></div><div class="mini-line"></div></div></div><div class="row between"><strong>${String(i + 1).padStart(2, "0")} · ${d.name}</strong><input class="switch" type="checkbox" data-device-enable="${d.id}" ${d.enabled ? "checked" : ""} title="Bật / tắt nhận việc"></div><div class="row between smalltext muted" style="margin-top:6px"><span>Android ${d.android}</span><span>${d.model}</span></div><div class="progress"><span style="width:${d.online ? "100" : "0"}%;background:${d.online ? "var(--green)" : "var(--line)"}"></span></div><div class="row"><button class="small grow" data-device-setup="${d.id}">${ic("list")} Thiết lập</button><button class="small grow" data-device-inspector="${d.id}" ${!d.online ? "disabled" : ""}>${ic("workflow")} Inspector</button></div></div>`;
}
function deviceContext(e, id) {
  state.device = id;
  showMenu(e.clientX, e.clientY, [
    ["device-info", "phone", "Thông tin thiết bị"],
    ["open-process", "list", "Thiết lập tiến trình"],
    ["open-inspector", "workflow", "Mở trong Inspector"],
    ["phone-refresh", "refresh", "Làm mới màn hình mẫu"],
    ["device-manager", "settings", "Quản lý & kết nối"],
  ]);
}
function contextKey() {
  return [
    state.device,
    state.app,
    state.workflow,
    state.account,
    state.target,
  ].join(":");
}
function saveContext() {
  state.contexts[contextKey()] = {
    rows: clone(state.rows),
    slots: clone(state.slots),
    daily: state.daily,
    startDate: state.startDate,
  };
}
function switchContext(changes) {
  saveContext();
  if (changes.workflow && changes.workflow !== state.workflow) {
    state.graphs["wf:" + state.workflow] = clone(state.graphs.main);
    state.graphs.main = state.graphs["wf:" + changes.workflow]
      ? clone(state.graphs["wf:" + changes.workflow])
      : mainGraph(changes.app || state.app);
  }
  Object.assign(state, changes);
  let stored = state.contexts[contextKey()];
  if (stored) {
    Object.assign(state, clone(stored));
  } else {
    state.rows = [];
    state.slots = ["08:00", "12:00", "19:00"];
    state.daily = 3;
  }
  save();
  render();
}
function renderProcess() {
  $("#main").innerHTML =
    `<div class="page"><div class="page-head"><div><div class="eyebrow">OPERATIONS / ${esc(dev().name.toUpperCase())}</div><h2>Thiết lập tiến trình</h2><p class="subtext">Mỗi đối tượng có danh sách nội dung và lịch riêng.</p></div><div class="row">${btn("clone-process", "copy", "Sao chép cấu hình")}${btn("process-options", "settings", "Tùy chọn")}${btn("process-save", "save", "Lưu tiến trình", "primary")}</div></div><div class="device-tabs">${devices.map((d, i) => `<button data-setup-device="${d.id}" class="${state.device === d.id ? "active" : ""}">${ic("phone")} ${i + 1}. ${d.name}</button>`).join("")}</div><div class="card"><div class="card-body"><div class="setup-grid"><div><label>1. Ứng dụng</label><select id="setup-app">${apps.map((a) => `<option value="${a.id}" ${a.id === state.app ? "selected" : ""}>${a.name}</option>`).join("")}</select></div><div><label>2. Quy trình</label><select id="setup-workflow">${state.workflows
      .filter((w) => w.app === state.app && w.kind === "main")
      .map(
        (w) =>
          `<option value="${w.id}" ${w.id === state.workflow ? "selected" : ""}>${esc(w.name)} · v${w.version}</option>`,
      )
      .join(
        "",
      )}</select></div><div><label>3. Account</label><div class="row"><select id="setup-account"><option value="a1" ${state.account === "a1" ? "selected" : ""}>Minh Anh · 2 đối tượng</option><option value="a2" ${state.account === "a2" ? "selected" : ""}>Hoàng Nam · 1 đối tượng</option></select>${btn("scan-accounts", "refresh", "Quét account", "icon")}</div></div><div><label>4. ${["fb", "lite"].includes(state.app) ? "Fanpage / Profile" : "Hồ sơ đăng nội dung"}</label><select id="setup-target">${(state.account ===
    "a1"
      ? [
          ["p1", "Green Living"],
          ["p2", "Daily Moments"],
        ]
      : [["p3", "Travel Notes"]]
    )
      .map(
        ([id, n]) =>
          `<option value="${id}" ${state.target === id ? "selected" : ""}>${n}</option>`,
      )
      .join(
        "",
      )}</select></div></div><div class="row wrap" style="margin-top:14px"><span class="badge purple">${esc(app().pkg)}</span><span class="badge green">Workflow v${wf().version} · cấu hình độc lập</span><span class="grow"></span>${btn("open-inspector", "workflow", "Mở workflow", "small")}${btn("input-mapping", "link", "Ánh xạ trường dữ liệu", "small")}</div></div></div><div class="card" style="margin-top:17px"><div class="card-head"><div class="row"><h3>Danh sách nội dung</h3><span class="badge" id="row-count">${state.rows.length} dòng</span></div><div class="row">${btn("folder", "folder", "Chọn thư mục", "small")}${btn("media", "plus", "Thêm tệp", "small")}${btn("import-data", "upload", "Nhập dữ liệu", "small")}${btn("export-csv", "download", "Xuất CSV", "small")}</div></div><div class="card-body" style="padding:10px 15px"><div class="row wrap"><div class="search" style="width:240px">${ic("search")}<input id="row-filter" placeholder="Tìm nội dung…" style="font-size:11px"></div><select id="row-status" style="font-size:11px"><option value="">Tất cả trạng thái</option><option>Chưa lên lịch</option><option>Đã lên lịch</option><option>Đã đăng · mẫu</option><option>Cần kiểm tra</option></select><span class="grow"></span>${btn("bulk-edit", "edit", "Sửa hàng loạt", "small")}${btn("add-row", "plus", "Thêm dòng", "small")}${btn("delete-rows", "trash", "Xóa dòng chọn", "small danger")}${btn("data-more", "more", "Tùy chọn nguồn", "icon")}</div></div><div class="data-table-wrap"><table id="content-table"><thead><tr><th><input type="checkbox" id="check-all" title="Chọn tất cả dòng đang hiện"></th><th>STT</th><th>Thumbnail / Nội dung</th><th>Caption</th><th>Hashtag</th><th>Thời lượng</th><th>Bình luận</th><th>Affiliate</th><th>Nơi lưu trữ</th><th>Lịch đăng</th><th>Trạng thái</th><th></th></tr></thead><tbody id="content-rows"></tbody></table></div><div class="row between" style="padding:11px 17px"><span class="tiny muted">1 dòng = 1 công việc · Tệp nguồn giữ trên PC · Chỉ chuyển khi đến lượt</span><button class="small ghost" data-action="demo-data">Nạp dữ liệu mẫu</button></div></div><div class="card" style="margin-top:17px"><div class="card-head"><h3>Lên lịch tự động</h3><span class="smalltext muted">Ngày/Tháng/Năm · Asia/Ho_Chi_Minh</span></div><div class="card-body"><div class="schedule-grid"><div><label>Số nội dung / ngày</label><input type="number" id="daily" min="1" value="${state.daily}" style="width:100%"><label style="margin-top:12px">Bắt đầu từ</label><input type="date" id="start-date" value="${state.startDate}" style="width:100%"></div><div><label>Khung giờ bắt đầu công việc</label><div class="slots">${state.slots
      .slice(state.slotPage || 0, (state.slotPage || 0) + 24)
      .map(
        (s, j) =>
          `<div class="slot"><span>${String(j + (state.slotPage || 0) + 1).padStart(2, "0")}</span><input type="time" data-slot="${j + (state.slotPage || 0)}" value="${s}"></div>`,
      )
      .join(
        "",
      )}</div>${state.slots.length > 24 ? `<div class="row" style="margin-top:8px"><button class="small" data-action="slots-prev">←</button><span class="tiny muted">Khung ${(state.slotPage || 0) + 1}–${Math.min((state.slotPage || 0) + 24, state.slots.length)} / ${state.slots.length}</span><button class="small" data-action="slots-next">→</button></div>` : ""}<div class="weekdays">${[
      [1, "T2"],
      [2, "T3"],
      [3, "T4"],
      [4, "T5"],
      [5, "T6"],
      [6, "T7"],
      [0, "CN"],
    ]
      .map(
        ([d, t]) =>
          `<button data-day="${d}" class="${state.weekdays.includes(d) ? "active" : ""}">${t}</button>`,
      )
      .join(
        "",
      )}</div><div class="row" style="margin-top:12px"><label class="checkbox-label"><input id="random-schedule" type="checkbox"> Ngẫu nhiên trong ± <input id="random-minutes" type="number" min="0" max="60" value="10" style="width:55px;padding:4px"> phút</label></div></div><div><label>Áp dụng cho</label><select id="schedule-scope" style="width:100%"><option value="unscheduled" ${state.scheduleScope === "unscheduled" ? "selected" : ""}>Các dòng chưa lên lịch</option><option value="selected" ${state.scheduleScope === "selected" ? "selected" : ""}>Các dòng đã chọn</option><option value="pending" ${state.scheduleScope === "pending" ? "selected" : ""}>Tất cả dòng chưa chạy</option></select><p class="muted tiny" style="margin:10px 0">Xem trước thay đổi trước khi áp dụng. Dòng đã đăng được giữ nguyên.</p><button data-action="schedule-preview" class="primary" style="width:100%">${ic("calendar")} Xem trước & áp dụng</button></div></div></div></div></div>`;
  renderRows();
  $("#setup-app").onchange = (e) => {
    let a = e.target.value,
      w = state.workflows.find((w) => w.app === a && w.kind === "main");
    switchContext({ app: a, workflow: w.id });
  };
  $("#setup-workflow").onchange = (e) =>
    switchContext({ workflow: e.target.value });
  $("#setup-account").onchange = (e) =>
    switchContext({
      account: e.target.value,
      target: e.target.value === "a1" ? "p1" : "p3",
    });
  $("#setup-target").onchange = (e) =>
    switchContext({ target: e.target.value });
  $("#row-filter").oninput = filterRows;
  $("#row-status").onchange = filterRows;
  $("#check-all").onchange = (e) => {
    $$("#content-rows tr")
      .filter((r) => r.style.display !== "none")
      .forEach((tr) => {
        let row = state.rows.find((r) => r.id === tr.dataset.row);
        row.checked = e.target.checked;
      });
    renderRows();
  };
  $("#daily").onchange = (e) => {
    let count = Math.max(1, Math.floor(+e.target.value) || 1);
    state.daily = count;
    state.slotPage = 0;
    state.slots = Array.from(
      { length: count },
      (_, i) =>
        state.slots[i] ||
        `${String(Math.floor(6 + (i * 16) / count) % 24).padStart(2, "0")}:${String(Math.floor((((i * 16) / count) % 1) * 60)).padStart(2, "0")}`,
    );
    renderProcess();
    save();
  };
  $("#start-date").onchange = (e) => {
    state.startDate = e.target.value;
    save();
  };
  $("#schedule-scope").onchange = (e) => (state.scheduleScope = e.target.value);
  $$("[data-slot]").forEach(
    (e) =>
      (e.onchange = () => {
        state.slots[+e.dataset.slot] = e.value;
        save();
      }),
  );
}
function renderRows() {
  let root = $("#content-rows");
  if (!root) return;
  root.innerHTML =
    state.rows
      .map(
        (r, i) =>
          `<tr data-row="${r.id}"><td><input type="checkbox" data-row-check="${r.id}" ${r.checked ? "checked" : ""}></td><td class="muted">${i + 1}</td><td><div class="row"><div class="thumb t${i % 4}">${ic("video")}</div><div><div class="filename">${esc(r.file)}</div><div class="file-meta">${r.files || 1} tệp · ID ${esc(r.id)}</div></div></div></td><td><textarea data-row-field="caption">${esc(r.caption)}</textarea></td><td><input data-row-field="hashtags" value="${esc(r.hashtags)}"></td><td>${esc(r.duration)}</td><td><textarea data-row-field="comments">${esc(r.comments)}</textarea></td><td><input data-row-field="affiliate" value="${esc(r.affiliate)}" placeholder="https://…"></td><td><span class="tiny muted" title="${esc(r.path)}">${esc(r.path.length > 30 ? "…" + r.path.slice(-29) : r.path)}</span></td><td style="white-space:nowrap">${r.scheduled ? dateVN(r.scheduled) : '<span class="muted">—</span>'}</td><td><span class="badge ${r.status === "Đã lên lịch" ? "purple" : r.status.includes("Đã đăng") ? "green" : r.status === "Cần kiểm tra" ? "amber" : ""}">${esc(r.status)}</span></td><td><button class="icon ghost" data-row-more="${r.id}" title="Chi tiết dòng">${ic("more")}</button></td></tr>`,
      )
      .join("") ||
    '<tr><td colspan="12"><div class="empty">Chọn thư mục hoặc thêm nội dung cho đối tượng này.<br><button class="small" data-action="demo-data" style="margin-top:10px">Thử bằng danh sách mẫu</button></div></td></tr>';
  $$("[data-row-check]", root).forEach(
    (e) =>
      (e.onchange = () =>
        (state.rows.find((r) => r.id === e.dataset.rowCheck).checked =
          e.checked)),
  );
  $$("[data-row-field]", root).forEach(
    (e) =>
      (e.onchange = () => {
        let r = state.rows.find((r) => r.id === e.closest("tr").dataset.row);
        r[e.dataset.rowField] = e.value;
        saveContext();
        save();
      }),
  );
  filterRows();
}
function filterRows() {
  let q = $("#row-filter")?.value.toLowerCase() || "",
    s = $("#row-status")?.value || "";
  $$("#content-rows tr[data-row]").forEach((tr) => {
    let r = state.rows.find((r) => r.id === tr.dataset.row);
    tr.style.display =
      JSON.stringify(r).toLowerCase().includes(q) && (!s || r.status === s)
        ? ""
        : "none";
  });
}
function dateVN(s) {
  if (!s) return "—";
  let d = new Date(s);
  if (isNaN(d)) return s;
  return d.toLocaleString("vi-VN", {
    timeZone: "Asia/Ho_Chi_Minh",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
function renderWorkflows() {
  $("#main").innerHTML =
    `<div class="page"><div class="page-head"><div><div class="eyebrow">REUSABLE AUTOMATION</div><h2>Thư viện workflow</h2><p class="subtext">Phân tách theo app. Tạo một lần, áp dụng trên nhiều điện thoại tương thích.</p></div><div class="row">${btn("import-workflow", "upload", "Nhập JSON")}${btn("new-workflow", "plus", "Tạo workflow", "primary")}</div></div><div class="toolbar">${apps.map((a) => `<button data-library-app="${a.id}" class="${state.app === a.id ? "active" : ""}">${appLogo(a)} ${a.name} <span class="badge">${state.workflows.filter((w) => w.app === a.id).length}</span></button>`).join("")}</div><div class="row between" style="margin:20px 0"><h3>${app().name} <span class="muted smalltext">· ${app().pkg}</span></h3><span class="badge">Workflow độc lập với điện thoại</span></div><div class="workflow-grid">${state.workflows
      .filter((w) => w.app === state.app)
      .map(
        (w) =>
          `<article class="card workflow-card"><div class="row between"><span class="badge ${w.kind === "sub" ? "purple" : "green"}">${w.kind === "sub" ? "QUY TRÌNH CON" : "QUY TRÌNH CHÍNH"}</span><button class="icon ghost" data-wf-menu="${w.id}" title="Quản lý workflow">${ic("more")}</button></div><h3>${esc(w.name)}</h3><div class="muted smalltext">Phiên bản ${w.version} · Có thể chỉnh sửa</div><div class="workflow-mini"><span></span><i></i><span></span><i></i><span></span><i></i><span></span></div><div class="row between" style="margin-top:16px"><span class="tiny muted">${w.kind === "sub" ? "Đầu vào / đầu ra có kiểu" : "Danh sách nội dung · Lịch chạy"}</span><button class="small" data-open-wf="${w.id}">${ic("external")} Mở</button></div></article>`,
      )
      .join(
        "",
      )}<button class="card" data-action="new-workflow" style="min-height:220px;border-style:dashed;flex-direction:column;color:var(--muted)">${ic("plus")} Tạo workflow cho ${app().name}</button></div><div class="notice" style="margin-top:22px">Facebook và Facebook Lite có bộ quy trình riêng. Các mẫu trong bản HTML minh họa cấu trúc, chưa xác nhận selector trên phiên bản app thực tế.</div></div>`;
}
function openWorkflow(id) {
  stopRun(false);
  let w = state.workflows.find((w) => w.id === id);
  if (!w) return;
  if (state.workflow !== id) {
    state.graphs["wf:" + state.workflow] = clone(state.graphs.main);
    state.graphs.main = state.graphs["wf:" + id]
      ? clone(state.graphs["wf:" + id])
      : mainGraph(w.app);
  }
  state.workflow = id;
  state.app = w.app;
  state.graphKey = "main";
  state.selected = [];
  state.view = "inspector";
  render();
  fit();
  save();
}
function renderSchedule() {
  let dates = Array.from({ length: 7 }, (_, i) => {
    let d = new Date(state.startDate + "T00:00:00+07:00");
    d.setUTCDate(d.getUTCDate() + i);
    return d.toLocaleDateString("en-CA", { timeZone: "Asia/Ho_Chi_Minh" });
  });
  $("#main").innerHTML =
    `<div class="page"><div class="page-head"><div><div class="eyebrow">SCHEDULE & QUEUE</div><h2>Lịch đăng & hàng đợi</h2><p class="subtext">Giờ dự kiến bắt đầu · Giữ riêng giờ chạy và giờ đăng thực tế.</p></div><div class="row">${btn("open-process", "list", "Thiết lập lịch")}${btn("queue", "list", "Hàng đợi")}</div></div><div class="toolbar"><label class="row" style="margin:0">Từ ngày <input id="timeline-date" type="date" value="${state.startDate}"></label><label class="row" style="margin:0">Điện thoại <select id="timeline-device"><option value="all">Tất cả máy</option>${devices.map((d) => `<option value="${d.id}">${d.name}</option>`).join("")}</select></label><span class="grow"></span><span class="badge purple">Lịch đang xem: cấu hình hiện tại</span></div><div class="card" style="overflow:auto"><div class="timeline"><div class="day">Điện thoại / ngày</div>${dates.map((d) => `<div class="day"><strong>${dateVN(d + "T00:00:00+07:00").split(" ")[1] || d}</strong><br><span class="muted">${new Date(d + "T12:00:00+07:00").toLocaleDateString("vi-VN", { weekday: "short", timeZone: "Asia/Ho_Chi_Minh" })}</span></div>`).join("")}${devices
      .map(
        (d, i) =>
          `<div class="timeline-device-name" data-tdev="${d.id}"><strong>${String(i + 1).padStart(2, "0")} · ${d.name}</strong><p class="muted tiny" style="margin-top:5px">1 thao tác tại một thời điểm</p></div>${dates
            .map(
              (dt) =>
                `<div class="timeline-cell" data-tdev="${d.id}" data-tdate="${dt}">${
                  d.id === state.device
                    ? state.rows
                        .filter((r) => r.scheduled?.startsWith(dt))
                        .map(
                          (r) =>
                            `<div class="event" draggable="true" data-event="${r.id}"><strong>${dateVN(r.scheduled).split(" ")[0]}</strong><br>${esc(r.file)}<br><span class="tiny">${esc(app().name)} · ${esc(state.target)}</span></div>`,
                        )
                        .join("")
                    : ""
                }</div>`,
            )
            .join("")}`,
      )
      .join(
        "",
      )}</div></div><div class="notice" style="margin-top:18px">Kéo một lịch sang ngày khác trên cùng máy để đổi ngày; giờ được giữ nguyên. Khác điện thoại cần sao chép / đổi cấu hình tiến trình.</div></div>`;
  $("#timeline-date").onchange = (e) => {
    state.startDate = e.target.value;
    renderSchedule();
  };
  $("#timeline-device").onchange = (e) =>
    $$("[data-tdev]").forEach(
      (c) =>
        (c.style.display =
          e.target.value === "all" || e.target.value === c.dataset.tdev
            ? ""
            : "none"),
    );
  $$("[data-event]").forEach(
    (e) =>
      (e.ondragstart = (ev) =>
        ev.dataTransfer.setData("text/plain", e.dataset.event)),
  );
  $$(".timeline-cell").forEach((c) => {
    c.ondragover = (e) => e.preventDefault();
    c.ondrop = (e) => {
      e.preventDefault();
      if (c.dataset.tdev !== state.device)
        return toast("Hãy đổi máy ở cấu hình tiến trình trước.");
      let r = state.rows.find(
        (r) => r.id === e.dataTransfer.getData("text/plain"),
      );
      if (!r) return;
      if (r.status.includes("Đã đăng"))
        return toast("Không đổi lịch dòng đã đăng");
      r.scheduled = c.dataset.tdate + r.scheduled.slice(10);
      saveContext();
      save();
      renderSchedule();
      toast("Đã đổi ngày của " + r.file);
    };
  });
}
function renderHistory() {
  $("#main").innerHTML =
    `<div class="page"><div class="page-head"><div><div class="eyebrow">EXECUTION OBSERVABILITY</div><h2>Lịch sử & đối soát</h2><p class="subtext">Xem từng lượt chạy, nhánh được chọn và kết quả cần xử lý.</p></div><div class="row">${btn("export-logs", "download", "Xuất nhật ký")}${btn("reconcile", "check", "Đối soát mẫu")}</div></div><div class="metric-grid">${[
      ["Lượt mô phỏng", state.history.length],
      [
        "Lượt hoàn tất",
        state.history.filter((h) => h.status === "Hoàn tất mô phỏng").length,
      ],
      ["Bài đăng thật", 0],
      ["Bình luận thật", 0],
    ]
      .map(
        ([t, n]) =>
          `<div class="card metric"><span class="muted smalltext">${t}</span><div class="number">${n}</div></div>`,
      )
      .join(
        "",
      )}</div><div class="card"><table><thead><tr><th>Thời gian</th><th>Workflow</th><th>Điện thoại</th><th>Trạng thái</th><th>Kết quả</th></tr></thead><tbody>${state.history.map((h) => `<tr><td>${dateVN(h.time)}</td><td>${esc(h.workflow)}</td><td>${esc(h.device)}</td><td><span class="badge purple">${esc(h.status)}</span></td><td>Chỉ chạy giao diện HTML</td></tr>`).join("") || '<tr><td colspan="5"><div class="empty">Chưa có lượt chạy. Mở Inspector và thử mô phỏng.</div></td></tr>'}</tbody></table></div><div class="card" style="margin-top:20px"><div class="card-head"><h3>Nhật ký gần đây</h3></div><div class="card-body" style="max-height:350px;overflow:auto">${
      state.logs
        .slice(0, 30)
        .map(
          (l) =>
            `<div class="log-line"><time>${l.time}</time><span class="level">${l.level}</span>${esc(l.message)}</div>`,
        )
        .join("") || '<div class="empty">Chưa có nhật ký</div>'
    }</div></div></div>`;
}
function modal(title, body, footer = "", wide = false) {
  $("#overlay").innerHTML =
    `<div class="modal-backdrop"><section class="modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-header"><h3>${esc(title)}</h3><button class="icon ghost" data-action="modal-close" title="Đóng">${ic("close")}</button></div><div class="modal-body">${body}</div><div class="modal-footer">${footer || btn("modal-close", null, "Đóng")}</div></section></div>`;
  $("#overlay .modal-backdrop").onclick = (e) => {
    if (e.target === e.currentTarget) closeModal();
  };
}
function closeModal() {
  $("#overlay").innerHTML = "";
}
function showMenu(x, y, items) {
  $("#context").innerHTML =
    `<div class="context-menu" style="left:${Math.min(x, innerWidth - 250)}px;top:${Math.min(y, innerHeight - (items.length * 36 + 20))}px">${items.map((i) => (i === null ? "<hr>" : `<button data-action="${i[0]}">${ic(i[1])}${i[2]}${i[3] ? `<span>${i[3]}</span>` : ""}</button>`)).join("")}</div>`;
}
function showCanvasMenu(x, y, type) {
  showMenu(
    x,
    y,
    type === "edge"
      ? [
          ["delete-selected", "trash", "Xóa liên kết", "Del"],
          ["insert-edge", "plus", "Chèn node vào dây"],
          ["reroute-edge", "link", "Thêm / bỏ điểm bẻ dây"],
        ]
      : type === "node"
        ? [
            ["run-selected", "play", "Chạy thử node"],
            ["run-from", "step", "Chạy từ node này"],
            ["advanced-node", "settings", "Cấu hình nâng cao"],
            ["rename-node", "edit", "Đổi tên", "F2"],
            ["duplicate", "copy", "Nhân bản", "Ctrl+D"],
            ["copy", "copy", "Sao chép", "Ctrl+C"],
            ["breakpoint", "flag", "Bật / tắt breakpoint"],
            null,
            ["group", "box", "Nhóm trực quan"],
            ["convert-sub", "workflow", "Chuyển thành quy trình con"],
            ["delete-selected", "trash", "Xóa node", "Del"],
          ]
        : [
            ["add-node", "plus", "Thêm node"],
            ["paste", "copy", "Dán node", "Ctrl+V"],
            ["select-all", "grid", "Chọn tất cả", "Ctrl+A"],
            null,
            ["layout", "layout", "Tự sắp xếp ngang"],
            ["layout-vertical", "layout", "Tự sắp xếp dọc"],
            ["align", "align", "Căn các node đã chọn"],
            ["fit", "fit", "Vừa canvas", "Ctrl+0"],
            ["minimap", "grid", "Bật / tắt minimap"],
            ["help", "help", "Phím tắt & hướng dẫn"],
          ],
  );
}
function addNodeMenu() {
  modal(
    "Thêm node",
    `<div class="search" style="margin-bottom:12px">${ic("search")}<input id="add-search" placeholder="Tìm thao tác…"></div><div id="add-list" style="display:grid;grid-template-columns:1fr 1fr;gap:5px">${catalog.map((c) => `<button data-modal-add="${c[0]}" style="justify-content:flex-start;font-size:11px">${ic(c[2])}${c[1]}</button>`).join("")}</div>`,
  );
  $("#add-search").oninput = (e) =>
    $$("[data-modal-add]").forEach(
      (b) =>
        (b.style.display = b.textContent
          .toLowerCase()
          .includes(e.target.value.toLowerCase())
          ? ""
          : "none"),
    );
}
function advancedNode() {
  let n = selectedNode();
  if (!n) return toast("Chọn một node trước");
  modal(
    "Cấu hình node · " + n.name,
    `<div class="form-grid two"><div><label>Tên node</label><input id="adv-name" value="${esc(n.name)}"></div><div><label>Thử lại an toàn (số lần)</label><input id="adv-retries" type="number" min="0" value="${n.retries}" ${n.effect ? "disabled" : ""}></div><div><label>Kiểu thao tác có tác động</label><select id="adv-effect"><option value="">Thao tác thông thường</option><option value="publish" ${n.effect === "publish" ? "selected" : ""}>Đăng nội dung · không retry mù</option><option value="comment" ${n.effect === "comment" ? "selected" : ""}>Gửi bình luận · kiểm tra trước retry</option></select></div><div><label>Thời lượng thao tác (ms)</label><input id="adv-duration" type="number" min="0" value="${n.duration || 450}"></div><div><label>Giới hạn vòng lặp / cuộn</label><input id="adv-loops" type="number" min="1" value="${n.maxLoops || 8}"></div><div><label>Ngưỡng khớp ảnh / OCR</label><input id="adv-confidence" type="number" min="0" max="1" step=".01" value="${n.confidence || 0.9}"></div><div><label>Điểm bắt đầu (x%, y%)</label><input id="adv-from" value="${esc(n.from || "50, 80")}"></div><div><label>Điểm kết thúc (x%, y%)</label><input id="adv-to" value="${esc(n.to || "50, 25")}"></div><div><label>Nhập văn bản</label><select id="adv-inputmode">${["Unicode / clipboard", "Gõ từng ký tự", "Nối thêm nội dung", "Thay nội dung"].map((t) => `<option ${n.inputmode === t ? "selected" : ""}>${t}</option>`).join("")}</select></div><div><label>Phạm vi lỗi</label><select id="adv-errorscope">${["Node → nhánh lỗi", "Dòng công việc", "Tiến trình / đối tượng", "Điện thoại"].map((t) => `<option ${n.errorscope === t ? "selected" : ""}>${t}</option>`).join("")}</select></div><div class="full"><label>Danh sách nhận diện dự phòng · mỗi dòng một cách</label><textarea id="adv-fallback" placeholder="resource-id=…&#10;ocr=Đăng&#10;image=publish-button">${esc(n.fallback || "")}</textarea></div><div class="full"><label>Ghi chú</label><input id="adv-desc" value="${esc(n.description)}"></div>${n.type === "condition" ? `<div><label>Kết quả giả lập khi chạy thử HTML</label><select id="adv-branch"><option value="true">Đúng</option><option value="false" ${n.testBranch === "false" ? "selected" : ""}>Sai</option><option value="error" ${n.testBranch === "error" ? "selected" : ""}>Lỗi</option></select></div>` : ""}</div><div class="notice">Thiết lập lưu trong bản nháp. Độ chính xác nhận diện, Unicode và thao tác đa điểm cần kiểm chứng khi tích hợp Android thật.</div>`,
    btn("modal-close", null, "Hủy") +
      btn("advanced-save", "save", "Lưu node", "primary"),
    true,
  );
}
function advancedSave() {
  let n = selectedNode();
  if (!n) return;
  checkpoint();
  Object.assign(n, {
    name: $("#adv-name").value,
    retries: +$("#adv-retries").value,
    effect: $("#adv-effect").value,
    duration: +$("#adv-duration").value,
    maxLoops: +$("#adv-loops").value,
    confidence: +$("#adv-confidence").value,
    from: $("#adv-from").value,
    to: $("#adv-to").value,
    inputmode: $("#adv-inputmode").value,
    errorscope: $("#adv-errorscope").value,
    fallback: $("#adv-fallback").value,
    description: $("#adv-desc").value,
    testBranch: $("#adv-branch")?.value || n.testBranch,
  });
  if (n.effect) n.retries = 0;
  closeModal();
  renderGraph();
  renderBottom();
  save();
}
function inputsModal() {
  modal(
    "Khai báo đầu vào của workflow",
    `<div class="notice">Trường của quy trình con được truyền vào từ quy trình cha. Setup hiển thị các trường theo khai báo này.</div><table><thead><tr><th>Tên biến</th><th>Kiểu dữ liệu</th><th>Phạm vi</th><th>Bắt buộc</th><th></th></tr></thead><tbody id="input-rows">${inputRows()}</tbody></table><button class="small" data-action="input-add" style="margin-top:12px">${ic("plus")} Thêm trường</button>`,
    btn("modal-close", null, "Đóng") +
      btn("inputs-save", "save", "Lưu khai báo", "primary"),
    true,
  );
}
function inputRows() {
  return state.inputs
    .map(
      (v, i) =>
        `<tr data-input-i="${i}"><td><input data-input-key value="${esc(v.key)}"></td><td><select data-input-type>${["text", "file", "file[]", "number", "boolean", "url", "list", "identity", "datetime"].map((t) => `<option ${t === v.type ? "selected" : ""}>${t}</option>`).join("")}</select></td><td><select data-input-scope>${["row", "process", "output"].map((t) => `<option ${t === v.scope ? "selected" : ""}>${t}</option>`).join("")}</select></td><td><input type="checkbox" data-input-required ${v.required ? "checked" : ""}></td><td><button data-input-delete="${i}" class="icon ghost" title="Xóa khai báo">${ic("trash")}</button></td></tr>`,
    )
    .join("");
}
function readInputForm() {
  return $$("[data-input-i]").map((tr) => ({
    key: $("[data-input-key]", tr).value.trim(),
    type: $("[data-input-type]", tr).value,
    scope: $("[data-input-scope]", tr).value,
    required: $("[data-input-required]", tr).checked,
  }));
}
function openSub(k) {
  if (!k || !state.graphs[k])
    return toast("Chọn quy trình con trong cấu hình khối");
  stopRun(false);
  state.graphKey = k;
  state.selected = [];
  renderInspector();
  fit();
}
function createSub() {
  modal(
    "Tạo quy trình con",
    `<label>Tên quy trình con</label><input id="new-sub-name" style="width:100%" placeholder="Ví dụ: Kiểm tra màn hình Home"><p class="muted smalltext" style="margin-top:10px">Khối con thuộc ${app().name}. Có đầu vào, đầu ra, phiên bản và các bước chỉnh sửa độc lập.</p>`,
    btn("modal-close", null, "Hủy") +
      btn("sub-create-confirm", "plus", "Tạo khối con", "primary"),
  );
}
function convertSub() {
  if (state.selected.length < 2)
    return toast("Chọn ít nhất hai node để chuyển thành quy trình con");
  const ids = state.selected,
    ins = graph().edges.filter((e) => !ids.includes(e.a) && ids.includes(e.b)),
    outs = graph().edges.filter((e) => ids.includes(e.a) && !ids.includes(e.b));
  modal(
    "Chuyển vùng chọn thành quy trình con",
    `<div class="notice">${ids.length} node · ${ins.length} dây vào · ${outs.length} dây ra. Bản xem trước hỗ trợ tự chuyển vùng có một lối vào và tối đa một lối ra.</div><label>Tên khối</label><input id="convert-name" style="width:100%" value="Khối thao tác mới"><p class="muted smalltext" style="margin-top:12px">Các biến giữ nguyên ánh xạ; có thể hoàn tác bằng Ctrl+Z.</p>`,
    btn("modal-close", null, "Hủy") +
      `<button class="primary" data-action="convert-confirm" ${ins.length > 1 || outs.length > 1 ? "disabled" : ""}>Chuyển thành khối con</button>`,
  );
}
function convertConfirm() {
  let name = $("#convert-name").value.trim();
  if (!name) return;
  checkpoint();
  let ids = [...state.selected],
    g = graph(),
    ns = g.nodes.filter((n) => ids.includes(n.id)),
    internal = g.edges.filter((e) => ids.includes(e.a) && ids.includes(e.b)),
    ins = g.edges.filter((e) => !ids.includes(e.a) && ids.includes(e.b)),
    outs = g.edges.filter((e) => ids.includes(e.a) && !ids.includes(e.b)),
    key = name + " " + uid("sub"),
    x = Math.min(...ns.map((n) => n.x)),
    y = Math.min(...ns.map((n) => n.y));
  let entry =
      ins[0]?.b ||
      ns.find((n) => !internal.some((e) => e.b === n.id))?.id ||
      ns[0].id,
    exit =
      outs[0]?.a ||
      ns.find((n) => !internal.some((e) => e.a === n.id))?.id ||
      ns.at(-1).id;
  state.graphs[key] = {
    nodes: [
      node(uid("n"), "start", "Đầu vào", 0, 0),
      ...clone(ns).map((n) => ({ ...n, x: n.x - x + 250, y: n.y - y + 50 })),
      node(uid("n"), "end", "Trả SUCCESS", 750, 500),
    ],
    edges: clone(internal),
    groups: [],
  };
  let sg = state.graphs[key];
  sg.edges.push(edge(sg.nodes[0].id, entry), edge(exit, sg.nodes.at(-1).id));
  let sub = node(uid("n"), "subflow", name, x, y, {
    sub: key,
    description: ns.length + " node · mở để chỉnh sửa",
  });
  g.nodes = g.nodes.filter((n) => !ids.includes(n.id));
  g.nodes.push(sub);
  g.edges = g.edges.filter((e) => !ids.includes(e.a) && !ids.includes(e.b));
  ins.forEach((e) => g.edges.push({ ...e, b: sub.id }));
  outs.forEach((e) => g.edges.push({ ...e, a: sub.id, port: "next" }));
  state.selected = [sub.id];
  closeModal();
  renderInspector();
  save();
}
function validation() {
  let errors = [],
    warnings = [],
    g = graph(),
    ids = new Set(g.nodes.map((n) => n.id));
  let starts = g.nodes.filter((n) => n.type === "start");
  if (starts.length !== 1) errors.push("Cần đúng một node Bắt đầu.");
  if (!g.nodes.some((n) => ["end", "review"].includes(n.type)))
    errors.push("Thiếu node Kết thúc / Cần kiểm tra.");
  g.edges.forEach((e) => {
    if (!ids.has(e.a) || !ids.has(e.b))
      errors.push("Liên kết " + e.id + " có node không tồn tại.");
  });
  g.nodes.forEach((n) => {
    if (n.type !== "start" && !g.edges.some((e) => e.b === n.id))
      warnings.push(n.name + ": chưa có đường vào.");
    ports(n).forEach((p) => {
      if (!g.edges.some((e) => e.a === n.id && e.port === p))
        errors.push(
          n.name +
            ": thiếu nhánh " +
            { true: "Đúng", false: "Sai", error: "Lỗi", next: "Tiếp tục" }[p],
        );
    });
    if (["tap", "type", "read", "find"].includes(n.type) && !n.selector)
      warnings.push(n.name + ": chưa có selector thực tế.");
    if (n.delayMin > n.delayMax)
      errors.push(n.name + ": khoảng chờ nhỏ nhất lớn hơn lớn nhất.");
    if (n.type === "subflow" && !state.graphs[n.sub])
      errors.push(n.name + ": chưa chọn khối con.");
    if (n.effect && n.retries > 0)
      errors.push(n.name + ": bước gửi / đăng phải tắt thử lại mù.");
  });
  let visited = new Set(),
    stack = new Set();
  function dfs(id) {
    if (stack.has(id)) return true;
    if (visited.has(id)) return false;
    visited.add(id);
    stack.add(id);
    for (let e of g.edges.filter((e) => e.a === id)) {
      if (dfs(e.b)) return true;
    }
    stack.delete(id);
    return false;
  }
  if (starts[0] && dfs(starts[0].id))
    errors.push(
      "Có chu kỳ dây tự do. Dùng node vòng lặp với giới hạn thay vì nối vòng trực tiếp.",
    );
  let recStack = new Set(),
    recSeen = new Set();
  function subCheck(key) {
    if (recStack.has(key)) return true;
    if (recSeen.has(key)) return false;
    recSeen.add(key);
    recStack.add(key);
    for (let n of state.graphs[key]?.nodes || []) {
      if (n.sub && subCheck(n.sub)) return true;
    }
    recStack.delete(key);
    return false;
  }
  if (subCheck(state.graphKey)) errors.push("Có lời gọi quy trình con đệ quy.");
  modal(
    "Kiểm tra workflow",
    `<div class="row" style="margin-bottom:16px"><span class="badge ${errors.length ? "red" : "green"}">${errors.length} lỗi cấu trúc</span><span class="badge amber">${warnings.length} mục cần cấu hình</span></div>${errors.map((t) => `<p class="smalltext" style="color:var(--red)">× ${esc(t)}</p>`).join("")}${warnings.map((t) => `<p class="smalltext muted">• ${esc(t)}</p>`).join("")}${!errors.length ? '<p class="smalltext">✓ Cấu trúc đang xem có đủ các nhánh bắt buộc.</p>' : ""}<div class="notice" style="margin-top:15px">Đây là kiểm tra đồ thị và cấu hình trong HTML. Không chứng nhận selector hay thao tác chạy được trên điện thoại thật.</div>`,
  );
  return errors;
}
function newWorkflow() {
  modal(
    "Tạo workflow",
    `<div class="form-grid two"><div><label>Ứng dụng</label><select id="new-wf-app">${apps.map((a) => `<option value="${a.id}" ${a.id === state.app ? "selected" : ""}>${a.name} · ${a.pkg}</option>`).join("")}</select></div><div><label>Loại</label><select id="new-wf-kind"><option value="main">Quy trình chính</option><option value="sub">Quy trình con</option></select></div><div class="full"><label>Tên quy trình</label><input id="new-wf-name" placeholder="Ví dụ: Đăng ảnh bảng tin"></div></div>`,
    btn("modal-close", null, "Hủy") +
      btn("new-workflow-confirm", "plus", "Tạo workflow", "primary"),
  );
}
function workflowMenu(id) {
  if (id && id !== state.workflow) openWorkflow(id);
  modal(
    "Quản lý · " + wf().name,
    `<div class="form-grid two"><div class="full"><label>Tên workflow</label><input id="wf-name" value="${esc(wf().name)}"></div><div><label>Phiên bản hiện tại</label><input value="v${wf().version}" disabled></div><div><label>App sở hữu</label><input value="${esc(app().name)}" disabled></div></div><div class="row wrap">${btn("workflow-duplicate", "copy", "Nhân bản")}${btn("export-workflow", "download", "Xuất workflow")}${btn("publish-version", "check", "Tạo phiên bản mới")}${btn("workflow-delete", "trash", "Xóa / lưu trữ", "danger")}</div><p class="muted smalltext" style="margin-top:15px">Lượt đang chạy giữ phiên bản đã chọn. Mẫu HTML lưu bản nháp và ảnh chụp cấu hình phiên bản cục bộ.</p>`,
    btn("modal-close", null, "Đóng") +
      btn("workflow-rename", "save", "Lưu tên", "primary"),
  );
}
function runPreview(startId, single = false) {
  if (state.view !== "inspector") {
    state.view = "inspector";
    render();
  }
  stopRun(false);
  const g = graph(),
    start = startId || g.nodes.find((n) => n.type === "start")?.id;
  if (!start) return toast("Workflow chưa có node Bắt đầu");
  runState = {
    current: start,
    paused: false,
    finished: false,
    steps: 0,
    single,
    graphKey: state.graphKey,
  };
  state.bottomTab = "logs";
  log(
    "Bắt đầu mô phỏng UI · " + wf().name + " · không thao tác Android",
    "DEMO",
  );
  renderBottom();
  tickRun();
}
function tickRun() {
  if (!runState || runState.finished || runState.paused) return;
  let n = graph().nodes.find((n) => n.id === runState.current);
  if (!n) return finishRun("Dừng: không tìm thấy node");
  renderGraph();
  log(
    n.name +
      (n.type === "subflow" ? " [khối con: " + subName(n.sub) + "]" : ""),
    "DEMO",
  );
  $("#status-detail").textContent =
    "Mô phỏng · " + n.name + " · bước " + ++runState.steps;
  if (runState.steps > 80) return finishRun("Dừng: giới hạn bước mô phỏng");
  if (n.breakpoint) {
    runState.paused = true;
    toast("Dừng tại breakpoint: " + n.name);
    renderBottom();
    return;
  }
  runTimer = setTimeout(() => {
    if (!runState || runState.paused) return;
    if (runState.single) return finishRun("Hoàn tất thử node");
    let ps = ports(n),
      p = ps.length > 1 ? n.testBranch || "true" : "next";
    let next = graph().edges.find((e) => e.a === n.id && e.port === p);
    if (next) {
      runState.current = next.b;
      tickRun();
    } else
      finishRun(
        ["end", "review"].includes(n.type)
          ? n.type === "end"
            ? "Hoàn tất mô phỏng"
            : "Cần đối soát · mô phỏng"
          : "Dừng: thiếu nhánh " + p,
      );
  }, 650);
}
function finishRun(status) {
  clearTimeout(runTimer);
  if (runState) runState.finished = true;
  log(status, "DEMO");
  state.history.unshift({
    time: new Date().toISOString(),
    workflow: wf().name,
    device: dev().name,
    status,
  });
  $("#status-detail").textContent = status;
  renderGraph();
  renderBottom();
  save();
  toast(status + " — không có nội dung được đăng thật");
}
function stopRun(notify = true) {
  clearTimeout(runTimer);
  if (runState && !runState.finished) {
    log("Đã dừng mô phỏng", "DEMO");
    if (notify) toast("Đã dừng phiên mô phỏng");
  }
  runState = null;
  renderGraph();
}
function schedulePreview() {
  if (new Set(state.slots).size !== state.slots.length)
    return toast(
      "Các khung giờ trong ngày bị trùng. Hãy chỉnh trước khi áp dụng.",
    );
  if (!state.weekdays.length) return toast("Chọn ít nhất một ngày trong tuần");
  if (
    !state.startDate ||
    !state.slots.length ||
    state.slots.some((s) => !/^\d\d:\d\d$/.test(s))
  )
    return toast("Kiểm tra ngày bắt đầu và khung giờ");
  let rows = state.rows.filter(
    (r) =>
      !r.status.includes("Đã đăng") &&
      (state.scheduleScope === "selected"
        ? r.checked
        : state.scheduleScope === "pending"
          ? true
          : !r.scheduled),
  );
  if (!rows.length) return toast("Không có dòng phù hợp để lên lịch");
  let dates = [],
    date = new Date(state.startDate + "T12:00:00Z"),
    slots = [...state.slots].sort(),
    random = $("#random-schedule")?.checked,
    range = Math.min(60, Math.max(0, +$("#random-minutes")?.value || 0));
  let iter = 0;
  while (dates.length < rows.length && iter++ < 10000) {
    if (state.weekdays.includes(date.getUTCDay())) {
      let day = date.toISOString().slice(0, 10);
      for (let time of slots) {
        let d = new Date(day + "T" + time + ":00+07:00");
        if (random)
          d = new Date(d.getTime() + (Math.random() * 2 - 1) * range * 60000);
        dates.push(
          d.toLocaleDateString("en-CA", { timeZone: "Asia/Ho_Chi_Minh" }) +
            "T" +
            d.toLocaleTimeString("en-GB", {
              timeZone: "Asia/Ho_Chi_Minh",
              hour: "2-digit",
              minute: "2-digit",
            }) +
            ":00+07:00",
        );
        if (dates.length === rows.length) break;
      }
    }
    date.setUTCDate(date.getUTCDate() + 1);
  }
  window.pendingSchedule = rows.map((r, i) => ({
    id: r.id,
    old: r.scheduled,
    next: dates[i],
    file: r.file,
  }));
  modal(
    "Xem trước lịch · " + rows.length + " nội dung",
    `<div class="notice">Lịch áp dụng riêng cho ${esc(dev().name)} · ${esc(app().name)} · ${esc(state.target)}. Đây là giờ bắt đầu dự kiến, không phải giờ bảo đảm bài xuất hiện.</div><table><thead><tr><th>Nội dung</th><th>Lịch cũ</th><th>Lịch mới</th></tr></thead><tbody>${window.pendingSchedule.map((p) => `<tr><td>${esc(p.file)}</td><td>${p.old ? dateVN(p.old) : "—"}</td><td>${dateVN(p.next)}</td></tr>`).join("")}</tbody></table>`,
    btn("modal-close", null, "Quay lại") +
      btn("schedule-apply", "check", "Áp dụng lịch", "primary"),
    true,
  );
}
function download(name, data, type = "application/json") {
  const b = new Blob(
      [typeof data === "string" ? data : JSON.stringify(data, null, 2)],
      { type },
    ),
    u = URL.createObjectURL(b),
    a = document.createElement("a");
  a.href = u;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(u), 1000);
}
function exportWorkflow() {
  download("AutoReels-" + wf().id + "-workflow.json", {
    format: "autoreels-preview-workflow-v1",
    workflow: clone(wf()),
    app: app().pkg,
    graphs: Object.fromEntries(
      Object.entries(state.graphs).filter(([k]) => !k.startsWith("wf:")),
    ),
    inputs: state.inputs,
  });
  toast("Đã xuất workflow JSON · không kèm nội dung đăng");
}
function parseCSV(text) {
  let rows = [],
    row = [],
    s = "",
    quoted = false;
  for (let i = 0; i < text.length; i++) {
    let c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') {
        s += '"';
        i++;
      } else quoted = !quoted;
    } else if (c === "," && !quoted) {
      row.push(s);
      s = "";
    } else if (c === "\n" && !quoted) {
      row.push(s.replace(/\r$/, ""));
      rows.push(row);
      row = [];
      s = "";
    } else s += c;
  }
  if (s || row.length) {
    row.push(s.replace(/\r$/, ""));
    rows.push(row);
  }
  return rows;
}
function exportCSV() {
  let keys = [
    "id",
    "file",
    "caption",
    "hashtags",
    "comments",
    "affiliate",
    "duration",
    "path",
    "scheduled",
    "status",
  ];
  download(
    "AutoReels-noi-dung.csv",
    "\uFEFF" +
      [keys, ...state.rows.map((r) => keys.map((k) => r[k] || ""))]
        .map((r) =>
          r.map((v) => '"' + String(v).replace(/"/g, '""') + '"').join(","),
        )
        .join("\r\n"),
    "text/csv;charset=utf-8",
  );
}
function importDataModal() {
  modal(
    "Nhập caption, hashtag, bình luận & dữ liệu",
    `<div class="notice">Bản HTML đọc CSV UTF-8 hoặc JSON trực tiếp. Với Excel (.xlsx), xuất thành CSV UTF-8 để thử tại đây; đọc .xlsx trực tiếp thuộc bản tích hợp.</div><div class="checks"><div class="check-row">① Ưu tiên khớp <strong>ID nội dung</strong></div><div class="check-row">② Sau đó đường dẫn tương đối</div><div class="check-row">③ Tên tệp duy nhất · không khớp theo số dòng</div></div><p class="muted smalltext" style="margin-top:15px">Cột: id, file, caption, hashtags, comments, affiliate. Dòng không khớp hoặc tên trùng sẽ được báo trước khi nhập.</p>`,
    btn("export-csv", "download", "Tải cấu trúc CSV hiện tại") +
      btn("pick-csv", "upload", "Chọn CSV / JSON", "primary"),
  );
}
async function importDataFile(file) {
  let text = await file.text(),
    data;
  try {
    if (file.name.endsWith(".json")) {
      data = JSON.parse(text);
      if (!Array.isArray(data)) throw Error("JSON phải là danh sách dòng");
    } else {
      let parsed = parseCSV(text.replace(/^\uFEFF/, "")),
        head = parsed.shift();
      data = parsed
        .filter((r) => r.some(Boolean))
        .map((r) =>
          Object.fromEntries(head.map((k, i) => [k.trim(), r[i] || ""])),
        );
    }
    let matches = [],
      unmatched = [];
    for (let d of data) {
      let found = state.rows.filter((r) => d.id && r.id === d.id);
      if (!found.length && d.path && d.file)
        found = state.rows.filter((r) => r.path + r.file === d.path + d.file);
      if (!found.length && d.file)
        found = state.rows.filter((r) => r.file === d.file);
      if (found.length === 1) matches.push({ id: found[0].id, data: d });
      else unmatched.push(d.file || d.id || "Không có khóa");
    }
    window.pendingImport = matches;
    modal(
      "Xem trước nhập dữ liệu",
      `<p><strong>${matches.length}</strong> dòng khớp · <strong>${unmatched.length}</strong> dòng không khớp / không rõ.</p><div class="notice">Chỉ cập nhật các cột caption, hashtags, comments và affiliate có trong tệp. Nội dung trống được hiểu là cố ý để trống.</div><table><thead><tr><th>ID nội dung</th><th>Caption mới</th></tr></thead><tbody>${matches.map((m) => `<tr><td>${esc(m.id)}</td><td>${esc(m.data.caption ?? "Giữ nguyên")}</td></tr>`).join("")}</tbody></table>${unmatched.length ? '<p class="smalltext muted" style="margin-top:12px">Không nhập: ' + unmatched.map(esc).join(", ") + "</p>" : ""}`,
      btn("modal-close", null, "Hủy") +
        btn("apply-import", "check", "Áp dụng dữ liệu", "primary"),
      true,
    );
  } catch (e) {
    toast("Không đọc được dữ liệu: " + e.message);
  }
}
async function addFiles(files) {
  let valid = [...files].filter((f) =>
    /\.(mp4|mov|mkv|webm|jpg|jpeg|png|webp)$/i.test(f.name),
  );
  if (!valid.length) return toast("Không có video / ảnh phù hợp");
  let added = 0;
  for (let f of valid) {
    let relative = f.webkitRelativePath || f.name;
    if (
      state.rows.some(
        (r) =>
          r.localRef === relative &&
          r.size === f.size &&
          r.modified === f.lastModified,
      )
    )
      continue;
    state.rows.push({
      id: uid("content-"),
      file: f.name,
      caption: f.name.replace(/\.[^.]+$/, ""),
      hashtags: "",
      comments: "",
      affiliate: "",
      duration: /\.(jpg|jpeg|png|webp)$/i.test(f.name) ? "Ảnh" : "Chưa đo",
      path: f.webkitRelativePath
        ? f.webkitRelativePath.slice(0, -f.name.length)
        : "Tệp được chọn/",
      localRef: relative,
      size: f.size,
      modified: f.lastModified,
      scheduled: "",
      status: "Chưa lên lịch",
      checked: false,
      files: 1,
    });
    added++;
  }
  saveContext();
  save();
  if (state.view === "process") renderProcess();
  toast(
    `Đã nhập ${added} tệp. Trình duyệt chỉ lưu thông tin, không sao chép tệp sang Android.`,
  );
}
function testData() {
  modal(
    "Dữ liệu chạy thử",
    `<div class="form-grid two"><div><label>Dòng nội dung</label><select id="test-row">${state.rows.map((r, i) => `<option value="${i}">${i + 1}. ${esc(r.file)}</option>`).join("")}</select></div><div><label>Kịch bản mô phỏng</label><select id="test-scenario"><option value="success">Đăng thành công, có bình luận</option><option value="no-comment">Đăng thành công, không bình luận</option><option value="ambiguous">Chưa rõ kết quả đăng → đối soát</option><option value="error">Lỗi đọc kết quả → đối soát</option></select></div></div><div class="notice">Mô phỏng chọn nhánh để xem đường đi. Không xác nhận hành vi thật của app, không tiêu thụ danh sách hay chạy lịch.</div>`,
    btn("modal-close", null, "Đóng") +
      btn("apply-test-data", "check", "Áp dụng kịch bản", "primary"),
  );
}
function sourceOptions() {
  modal(
    "Tùy chọn nguồn nội dung",
    `<div class="checks">${[
      ["subfolders", "Quét cả thư mục con", false],
      ["watcher", "Tự theo dõi tệp mới (bản tích hợp)", false],
      [
        "append",
        "Tự xếp tệp mới vào các khung giờ tương lai",
        state.settings.autoAppend,
      ],
      [
        "dedupe",
        "Chống trùng theo nội dung + app + đối tượng",
        state.settings.dedupe,
      ],
    ]
      .map(
        ([id, t, v]) =>
          `<label class="checkbox-label"><input id="source-${id}" type="checkbox" ${v ? "checked" : ""}>${t}</label>`,
      )
      .join(
        "",
      )}</div><div class="notice" style="margin-top:16px">Quét thư mục trong HTML cần bạn chọn lại tệp. Watcher nền, hash nội dung và truyền ADB cần bản desktop.</div>`,
    btn("modal-close", null, "Đóng") +
      btn("source-save", "save", "Lưu cấu hình", "primary"),
  );
}
function settings() {
  modal(
    "Cài đặt workspace",
    `<div class="form-grid two"><div><label>Giao diện</label><select id="set-theme"><option value="light" ${state.settings.theme === "light" ? "selected" : ""}>Sáng</option><option value="dark" ${state.settings.theme === "dark" ? "selected" : ""}>Tối</option></select></div><div><label>Múi giờ hiển thị</label><input value="Asia/Ho_Chi_Minh · DD/MM/YYYY" disabled></div><div><label>Khi quá giờ</label><select id="set-overdue"><option value="next" ${state.settings.overdue === "next" ? "selected" : ""}>Chuyển tới khung tương lai</option><option value="catchup" ${state.settings.overdue === "catchup" ? "selected" : ""}>Xếp hàng chạy bù</option><option value="skip" ${state.settings.overdue === "skip" ? "selected" : ""}>Bỏ qua lượt</option></select></div><div><label>Dọn nội dung trên điện thoại</label><select><option>Đã xác minh đăng & không cần phục hồi</option></select></div></div><div class="row wrap">${btn("export-workspace", "download", "Sao lưu workspace")}${btn("restore-workspace", "upload", "Khôi phục JSON")}${btn("reset-preview", "refresh", "Đặt lại dữ liệu mẫu", "danger")}</div><div class="notice" style="margin-top:16px">HTML lưu trên trình duyệt hiện tại. Xuất JSON để giữ bản chỉnh sửa hoặc chuyển máy. Không chứa tệp media gốc.</div>`,
    btn("modal-close", null, "Đóng") +
      btn("settings-save", "save", "Lưu cài đặt", "primary"),
  );
}
function help() {
  modal(
    "Hướng dẫn & phím tắt",
    `<div class="notice">Bắt đầu: chọn điện thoại mẫu → mở Inspector → kéo node → chọn phần tử → nối cổng → sửa thuộc tính → chạy mô phỏng. Sang Tiến trình để thử nguồn dữ liệu và lịch.</div><table><thead><tr><th>Thao tác</th><th>Phím / cách dùng</th></tr></thead><tbody>${[
      ["Lưu bản nháp", "Ctrl+S"],
      ["Hoàn tác / làm lại", "Ctrl+Z / Ctrl+Y"],
      ["Sao chép / dán / nhân bản", "Ctrl+C / Ctrl+V / Ctrl+D"],
      ["Chọn tất cả node", "Ctrl+A khi canvas có focus"],
      ["Tìm node trong thư viện", "Ctrl+F"],
      ["Đổi tên node / xóa", "F2 / Delete"],
      ["Phóng to theo con trỏ", "Ctrl + cuộn chuột"],
      ["Vừa canvas", "Ctrl+0"],
      ["Di chuyển canvas", "Kéo nền / Space + kéo"],
      ["Chọn nhiều node", "Shift + bấm / Shift + kéo vùng"],
      ["Mở quy trình con", "Bấm đúp khối hoặc icon mở"],
      ["Menu ngữ cảnh", "Chuột phải node, dây hoặc canvas"],
      ["Hủy nối dây / đóng hộp thoại", "Esc"],
    ]
      .map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`)
      .join(
        "",
      )}</tbody></table><p class="muted smalltext" style="margin-top:12px">Phím tắt chỉnh sửa không can thiệp khi đang gõ trong ô nhập. Undo không thu hồi thao tác đã thực hiện trên điện thoại thật.</p><button data-action="coverage" class="small">${ic("list")} Xem phạm vi chức năng bản HTML</button>`,
    null,
    true,
  );
}
const coverage = [
  [
    "Điện thoại",
    "Danh sách, tìm kiếm, bật/tắt, nhóm chọn, cấu hình theo máy",
    "Tương tác với dữ liệu mẫu",
  ],
  [
    "Inspector canvas",
    "Kéo node, kéo nối dây, chọn nhiều, zoom, pan, căn chỉnh, minimap",
    "Tương tác",
  ],
  [
    "Editor",
    "Thuộc tính, timeout, delay, dữ liệu, nhận diện dự phòng, tác động",
    "Lưu cấu hình",
  ],
  [
    "Quy trình con",
    "Mở / sửa, tạo mới, chuyển vùng chọn đơn lối vào/ra",
    "Tương tác có giới hạn được báo",
  ],
  [
    "Phiên bản workflow",
    "Tạo, đổi tên, nhân bản, lưu, nhập/xuất, phiên bản mới",
    "Lưu cục bộ",
  ],
  [
    "Điện thoại bên cạnh",
    "Dock phải/trên, cửa sổ nổi, popup, resize, zoom",
    "Màn hình minh họa",
  ],
  [
    "Nhận diện",
    "XPath, thuộc tính, ảnh, OCR, tọa độ và dự phòng",
    "Form cấu hình + chọn phần tử mẫu",
  ],
  [
    "Debug",
    "Chạy node, chạy từ node, breakpoint, bước tiếp, log, chọn kịch bản",
    "Mô phỏng đồ thị, không chạy Android",
  ],
  ["Đầu vào", "Khai báo kiểu/phạm vi/bắt buộc, ánh xạ dữ liệu", "Lưu cấu hình"],
  [
    "Nội dung",
    "Chọn thư mục/tệp, sửa từng dòng, sửa nhóm, nhập CSV/JSON, xuất CSV",
    "Tương tác; tệp media không được lưu trong HTML",
  ],
  [
    "Lịch",
    "N khung/ngày, chọn ngày, ngẫu nhiên, phạm vi, xem trước, kéo đổi ngày",
    "Tính & lưu lịch; không có scheduler nền",
  ],
  ["Phiên chạy", "Nhật ký, lịch sử mô phỏng, xuất nhật ký", "Tương tác"],
  [
    "An toàn thực thi",
    "Mutex máy/target, POST_INTENT, chống đăng trùng, phục hồi",
    "Đặc tả / cấu hình; cần backend desktop",
  ],
  [
    "Tích hợp Android",
    "ADB, scrcpy, đọc UI, OCR thật, media staging, MediaStore",
    "Chưa kết nối trong bản HTML",
  ],
  [
    "Nhập Excel",
    "CSV UTF-8 xuất từ Excel; .xlsx trực tiếp",
    "CSV chạy được; .xlsx cần bản tích hợp",
  ],
  [
    "Nâng cao canvas",
    "Tự cuộn sát mép, điểm bẻ dây, thu gọn nhóm, resize node",
    "Tương tác",
  ],
  [
    "Thiết bị & nguồn",
    "Quét app/account thật, watcher, probing duration, SHA fingerprint",
    "Cần backend desktop",
  ],
  [
    "Hiệu năng & phục hồi",
    "Ảnh chụp/XML đồng bộ, reconnect, backup SQLite, quản lý tài nguyên",
    "Cần backend desktop",
  ],
];
function coverageModal() {
  modal(
    "Phạm vi bản HTML · rõ phần có thể thử",
    `<div class="notice">Bản xem trước bao phủ các màn hình và luồng chính. Bảng dưới phân biệt phần đang tương tác được với phần cần triển khai Android/desktop; không xem HTML là phần mềm hoàn chỉnh.</div><table><thead><tr><th>Nhóm</th><th>Phạm vi</th><th>Trạng thái</th></tr></thead><tbody>${coverage.map((r) => `<tr><td><strong>${r[0]}</strong></td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join("")}</tbody></table>`,
    null,
    true,
  );
}
function phonePick() {
  if (!state.inspect) {
    toast("Thao tác minh họa trên khung hình mẫu · chưa có Android thật");
    return;
  }
  let n = selectedNode();
  modal(
    "Phần tử được chọn · snapshot minh họa",
    `<div class="form-grid two"><div><label>Class</label><input value="android.widget.Button" readonly></div><div><label>Resource ID</label><input value="create_post" readonly></div><div><label>Text / content-desc</label><input value="Tạo bài viết" readonly></div><div><label>Bounds</label><input value="[42,650][1038,780]" readonly></div></div><label>XPath gợi ý</label><div class="selector-preview">//*[@resource-id="create_post"]</div><div class="row wrap" style="margin-top:12px"><span class="badge green">1 phần tử · dữ liệu mẫu</span><span class="badge">clickable: true</span><span class="badge">enabled: true</span></div><p class="muted smalltext" style="margin-top:12px">${n ? "Áp dụng vào node: " + esc(n.name) : "Chưa chọn node. Có thể tạo node Bấm phần tử mới."}</p>`,
    btn("modal-close", null, "Đóng") +
      btn(
        "use-selector",
        "tap",
        n ? "Gắn vào node đang chọn" : "Tạo node bấm",
        "primary",
      ),
  );
}
function dockMenu() {
  modal(
    "Bố trí điện thoại kiểm thử",
    `<div class="row wrap">${btn("dock-right", "layout", "Dính bên phải")}${btn("dock-top", "layout", "Dính phía trên")}${btn("dock-floating", "external", "Cửa sổ nổi trong tool")}${btn("phone-popup", "external", "Popup cửa sổ riêng")}</div><p class="muted smalltext" style="margin-top:16px">Điện thoại luôn hiển thị cùng canvas. Kéo đường phân cách để đổi chiều rộng; cửa sổ nổi có thể kéo và thay đổi kích thước.</p>`,
  );
}
function floatPhone() {
  let pane = $("#phone-pane");
  if (!pane) return;
  pane.classList.add("phone-floating");
  let h = $(".phone-heading", pane);
  h.classList.add("floating-handle");
  h.onpointerdown = (e) => {
    if (e.target.closest("button,select")) return;
    let rect = pane.getBoundingClientRect(),
      sx = e.clientX,
      sy = e.clientY;
    const move = (ev) => {
      pane.style.left =
        Math.max(65, Math.min(innerWidth - 100, rect.left + ev.clientX - sx)) +
        "px";
      pane.style.top =
        Math.max(55, Math.min(innerHeight - 100, rect.top + ev.clientY - sy)) +
        "px";
      pane.style.right = "auto";
    };
    window.addEventListener("pointermove", move);
    window.addEventListener(
      "pointerup",
      () => window.removeEventListener("pointermove", move),
      { once: true },
    );
  };
}
function popupPhone() {
  closeModal();
  if (currentPopup && !currentPopup.closed) {
    currentPopup.focus();
    return;
  }
  currentPopup = window.open(
    "",
    "AutoReelsPhone",
    "width=420,height=800,resizable=yes",
  );
  if (!currentPopup) {
    toast(
      "Trình duyệt chặn popup. Đã chuyển điện thoại sang cửa sổ nổi trong tool.",
    );
    state.phoneDock = "floating";
    renderInspector();
    return;
  }
  const style = $("style").textContent;
  currentPopup.document.write(
    `<!doctype html><html lang="vi"><meta charset="utf-8"><title>Điện thoại kiểm thử · ${esc(dev().name)}</title><style>${style}body{overflow:auto;background:#f3f5f9}.phone-pane{width:100%;max-width:none;height:100vh}.phone-device{width:300px;min-height:540px}</style><body>${phonePane()}<script>document.querySelectorAll('button').forEach(b=>b.onclick=()=>{window.opener.postMessage({type:'autoreels-phone-action',action:b.dataset.action},'*')});<\/script></body></html>`,
  );
  currentPopup.document.close();
  currentPopup.onbeforeunload = () => {
    currentPopup = null;
    toast("Popup đã đóng; điện thoại vẫn hiển thị trong Inspector");
  };
  toast("Đã mở điện thoại ở cửa sổ riêng");
}
window.addEventListener("message", (e) => {
  if (e.source === currentPopup && e.data?.type === "autoreels-phone-action")
    action(e.data.action);
});
function action(a, el) {
  switch (a) {
    case "slots-prev":
      state.slotPage = Math.max(0, (state.slotPage || 0) - 24);
      renderProcess();
      break;
    case "slots-next":
      state.slotPage = Math.min(
        Math.floor((state.slots.length - 1) / 24) * 24,
        (state.slotPage || 0) + 24,
      );
      renderProcess();
      break;
    case "reroute-edge": {
      let ed = graph().edges.find((e) => e.id === state.edgeSelected);
      if (ed) {
        checkpoint();
        let a = graph().nodes.find((n) => n.id === ed.a),
          b = graph().nodes.find((n) => n.id === ed.b);
        ed.reroute = ed.reroute
          ? null
          : { x: (a.x + b.x + 190) / 2, y: (a.y + b.y) / 2 - 40 };
        renderGraph();
        save();
      }
      break;
    }
    case "modal-close":
      closeModal();
      break;
    case "save":
      save();
      toast("Đã lưu bản nháp workflow trong trình duyệt");
      break;
    case "undo":
      undo();
      break;
    case "redo":
      redo();
      break;
    case "fit":
      fit();
      break;
    case "zoom-in":
      state.zoom = Math.min(1.8, state.zoom * 1.15);
      renderGraph();
      break;
    case "zoom-out":
      state.zoom = Math.max(0.25, state.zoom / 1.15);
      renderGraph();
      break;
    case "snap":
      state.snap = !state.snap;
      renderInspector();
      break;
    case "minimap":
      state.showMini = !state.showMini;
      renderMini();
      break;
    case "focus":
      state.focus = !state.focus;
      renderInspector();
      break;
    case "bottom-toggle": {
      let e = $(".inspector-bottom");
      e.style.height = e.offsetHeight < 100 ? "219px" : "40px";
      e.style.minHeight = e.offsetHeight < 100 ? "110px" : "40px";
      break;
    }
    case "parent":
      stopRun(false);
      state.graphKey = "main";
      state.selected = [];
      renderInspector();
      fit();
      break;
    case "open-selected-sub":
      openSub(selectedNode()?.sub);
      break;
    case "new-sub":
      createSub();
      break;
    case "sub-create-confirm": {
      let name = $("#new-sub-name").value.trim();
      if (!name) return toast("Nhập tên quy trình con");
      checkpoint();
      let key = name + " " + uid("sub");
      state.graphs[key] = {
        nodes: [
          node("start", "start", "Đầu vào", 40, 60),
          node("end", "end", "Trả SUCCESS", 350, 60),
        ],
        edges: [edge("start", "end")],
        groups: [],
      };
      closeModal();
      openSub(key);
      save();
      break;
    }
    case "add-node":
      addNodeMenu();
      break;
    case "duplicate":
      duplicateSelected();
      break;
    case "copy":
      clipboard = {
        nodes: clone(
          graph().nodes.filter((n) => state.selected.includes(n.id)),
        ),
        edges: clone(
          graph().edges.filter(
            (e) => state.selected.includes(e.a) && state.selected.includes(e.b),
          ),
        ),
      };
      toast("Đã sao chép " + clipboard.nodes.length + " node");
      break;
    case "paste":
      pasteNodes();
      break;
    case "select-all":
      state.selected = graph().nodes.map((n) => n.id);
      renderGraph();
      renderBottom();
      break;
    case "delete-selected":
      removeSelected();
      break;
    case "rename-node":
      if (selectedNode()) {
        modal(
          "Đổi tên node",
          `<input id="rename-node-value" style="width:100%" value="${esc(selectedNode().name)}">`,
          btn("modal-close", null, "Hủy") +
            btn("rename-confirm", "check", "Lưu", "primary"),
        );
      }
      break;
    case "rename-confirm":
      if (selectedNode()) {
        checkpoint();
        selectedNode().name =
          $("#rename-node-value").value.trim() || selectedNode().name;
        closeModal();
        renderGraph();
        renderBottom();
        save();
      }
      break;
    case "layout":
    case "layout-vertical": {
      checkpoint();
      let vertical = a === "layout-vertical";
      graph().nodes.forEach((n, i) => {
        n.x = 40 + (vertical ? Math.floor(i / 5) : i % 4) * 255;
        n.y = 50 + (vertical ? i % 5 : Math.floor(i / 4)) * 185;
      });
      renderGraph();
      fit();
      save();
      break;
    }
    case "align": {
      if (state.selected.length < 2)
        return toast("Chọn nhiều node trước khi căn chỉnh");
      checkpoint();
      let ns = graph().nodes.filter((n) => state.selected.includes(n.id)),
        y = Math.min(...ns.map((n) => n.y));
      ns.sort((a, b) => a.x - b.x).forEach((n, i) => {
        n.y = y;
        n.x = ns[0].x + i * 245;
      });
      renderGraph();
      save();
      break;
    }
    case "group": {
      if (state.selected.length < 2)
        return toast("Chọn ít nhất hai node để nhóm");
      checkpoint();
      let ns = graph().nodes.filter((n) => state.selected.includes(n.id)),
        x = Math.min(...ns.map((n) => n.x)) - 15,
        y = Math.min(...ns.map((n) => n.y)) - 15,
        w = Math.max(...ns.map((n) => n.x)) + 210 - x,
        h = Math.max(...ns.map((n) => n.y)) + 130 - y;
      graph().groups.push({
        id: uid("g"),
        name: "Nhóm thao tác " + (graph().groups.length + 1),
        x,
        y,
        w,
        h,
        nodeIds: [...state.selected],
      });
      renderGraph();
      save();
      break;
    }
    case "convert-sub":
      convertSub();
      break;
    case "convert-confirm":
      convertConfirm();
      break;
    case "insert-edge":
      if (state.edgeSelected) {
        window.edgeToInsert = state.edgeSelected;
        addNodeMenu();
      } else toast("Chọn một dây nối trước");
      break;
    case "canvas-menu": {
      let r = el?.getBoundingClientRect() || { left: 400, bottom: 150 };
      showCanvasMenu(r.left, r.bottom, "canvas");
      break;
    }
    case "node-run":
      state.selected = [el.dataset.id];
      runPreview(el.dataset.id, true);
      break;
    case "node-stop":
    case "stop":
      stopRun();
      renderBottom();
      break;
    case "node-edit":
      state.selected = [el.dataset.id];
      renderGraph();
      renderBottom();
      break;
    case "node-copy":
      state.selected = [el.dataset.id];
      duplicateSelected();
      break;
    case "node-delete":
      state.selected = [el.dataset.id];
      removeSelected();
      break;
    case "node-open": {
      let n = graph().nodes.find((n) => n.id === el.dataset.id);
      openSub(n?.sub);
      break;
    }
    case "node-more": {
      state.selected = [el.dataset.id];
      let r = el.getBoundingClientRect();
      showCanvasMenu(r.left, r.bottom, "node");
      break;
    }
    case "advanced-node":
      advancedNode();
      break;
    case "advanced-save":
      advancedSave();
      break;
    case "validate":
      validation();
      break;
    case "run":
      testData();
      break;
    case "run-selected":
      if (selectedNode()) runPreview(selectedNode().id, true);
      else toast("Chọn node để chạy");
      break;
    case "run-from":
      if (selectedNode()) runPreview(selectedNode().id);
      else toast("Chọn node để chạy");
      break;
    case "test-data":
      testData();
      break;
    case "apply-test-data": {
      let scenario = $("#test-scenario").value;
      let n9 = state.graphs.main.nodes.find((n) => n.id === "n9"),
        n10 = state.graphs.main.nodes.find((n) => n.id === "n10");
      if (n9)
        n9.testBranch =
          scenario === "ambiguous"
            ? "false"
            : scenario === "error"
              ? "error"
              : "true";
      if (n10) n10.testBranch = scenario === "no-comment" ? "false" : "true";
      let idx = +$("#test-row").value;
      if (state.rows[idx]) state.testRowId = state.rows[idx].id;
      closeModal();
      runPreview();
      break;
    }
    case "pause":
      if (runState) {
        runState.paused = !runState.paused;
        if (!runState.paused) tickRun();
        renderBottom();
        toast(runState.paused ? "Đã tạm dừng mô phỏng" : "Tiếp tục mô phỏng");
      }
      break;
    case "breakpoint":
      if (selectedNode()) {
        checkpoint();
        selectedNode().breakpoint = !selectedNode().breakpoint;
        renderGraph();
        save();
        toast(
          selectedNode().breakpoint ? "Đã đặt breakpoint" : "Đã bỏ breakpoint",
        );
      } else toast("Chọn node để đặt breakpoint");
      break;
    case "debug-step":
      {
        if (!runState) {
          let n = selectedNode() || graph().nodes[0];
          if (n) runPreview(n.id, true);
        } else {
          clearTimeout(runTimer);
          let n = graph().nodes.find((n) => n.id === runState.current),
            p = ports(n).length > 1 ? n.testBranch || "true" : "next",
            next = graph().edges.find((e) => e.a === n.id && e.port === p);
          if (next) {
            runState.current = next.b;
            runState.paused = true;
            log(
              "Bước tới " + graph().nodes.find((n) => n.id === next.b)?.name,
              "DEMO",
            );
            renderGraph();
            renderBottom();
          } else toast("Không còn bước tiếp theo");
        }
      }
      break;
    case "debug-into": {
      let n =
        selectedNode() || graph().nodes.find((n) => n.id === runState?.current);
      if (n?.sub) openSub(n.sub);
      else toast("Chọn node quy trình con để đi vào");
      break;
    }
    case "inputs":
      inputsModal();
      break;
    case "input-add":
      state.inputs = readInputForm();
      state.inputs.push({
        key: "field" + (state.inputs.length + 1),
        type: "text",
        scope: "row",
        required: false,
      });
      $("#input-rows").innerHTML = inputRows();
      break;
    case "inputs-save": {
      let data = readInputForm(),
        keys = data.map((d) => d.key);
      if (
        keys.some((k) => !/^\w+$/.test(k)) ||
        new Set(keys).size !== keys.length
      )
        return toast(
          "Tên biến phải duy nhất, không dấu, không có khoảng trắng",
        );
      checkpoint();
      state.inputs = data;
      closeModal();
      save();
      toast("Đã lưu khai báo đầu vào");
      break;
    }
    case "pick":
      state.inspect = true;
      if ($("#phone-screen")) {
        $("#phone-screen").innerHTML = phoneScreen();
        phonePick();
      } else toast("Mở Inspector để chọn phần tử");
      break;
    case "use-selector": {
      let n = selectedNode();
      if (n) {
        checkpoint();
        n.selector = '//*[@resource-id="create_post"]';
        n.method = "XPath / thuộc tính";
      } else {
        n = addNode("tap");
        n.selector = '//*[@resource-id="create_post"]';
      }
      closeModal();
      renderGraph();
      renderBottom();
      save();
      toast("Đã gắn selector mẫu vào node");
      break;
    }
    case "refresh-tree":
      log("Đã làm mới snapshot minh họa", "DEMO");
      toast("Đã nạp lại cây UI mẫu");
      break;
    case "phone-control":
      state.inspect = false;
      renderInspector();
      toast("Chế độ thao tác minh họa. Android thật chưa kết nối.");
      break;
    case "phone-refresh":
      if ($("#phone-screen")) $("#phone-screen").innerHTML = phoneScreen();
      toast("Đã nạp lại khung hình mẫu");
      break;
    case "phone-fit":
      if ($("#phone-screen")) $("#phone-screen").style.transform = "scale(1)";
      if ($("#phone-zoom")) $("#phone-zoom").value = 100;
      break;
    case "phone-back":
    case "phone-home":
    case "phone-recent":
      log("Nút " + a.replace("phone-", "") + " · chỉ minh họa", "DEMO");
      toast("Điều khiển mẫu: " + a.replace("phone-", ""));
      break;
    case "phone-dock":
      dockMenu();
      break;
    case "phone-popup":
      popupPhone();
      break;
    case "dock-right":
    case "dock-top":
    case "dock-floating":
      state.phoneDock = a.replace("dock-", "");
      closeModal();
      renderInspector();
      save();
      break;
    case "device-info":
      modal(
        "Thông tin điện thoại kiểm thử",
        `<div class="notice">Thiết bị mẫu dùng để xem giao diện.</div><table>${[
          ["Tên", dev().name],
          ["Model", dev().model],
          ["Android", dev().android],
          ["Serial minh họa", dev().serial],
          ["Quyền thao tác", "Chưa kết nối backend"],
          ["App hiện tại", app().name],
          ["Tính tương thích", "Chưa kiểm thử thật"],
        ]
          .map(([k, v]) => `<tr><td>${k}</td><td>${esc(v)}</td></tr>`)
          .join("")}</table>`,
      );
      break;
    case "scan-devices":
      toast(
        "Đã làm mới " +
          devices.length +
          " thiết bị mẫu. Quét ADB thật cần bản desktop.",
      );
      break;
    case "device-manager":
      modal(
        "Quản lý thiết bị",
        `<div class="notice">Kết nối USB/LAN, cài APK và quét app là chức năng của bản desktop. Bản HTML cho xem cấu hình và cách quản lý.</div><div class="form-grid two"><div><label>Địa chỉ thiết bị LAN</label><input placeholder="192.168.1.100:5555"></div><div><label>Transport</label><select><option>USB · ADB</option><option>LAN · TCP</option></select></div></div><table><thead><tr><th>Thiết bị</th><th>Android</th><th>Trạng thái mẫu</th><th>Cho nhận việc</th></tr></thead><tbody>${devices.map((d) => `<tr><td>${d.name}</td><td>${d.android}</td><td>${d.online ? "Online" : "Offline"}</td><td><input class="switch" data-device-enable="${d.id}" type="checkbox" ${d.enabled ? "checked" : ""}></td></tr>`).join("")}</tbody></table>`,
      );
      break;
    case "device-bulk": {
      let ids = $$(".device-select:checked").map((e) => e.value);
      if (!ids.length) return toast("Chọn máy bằng ô chọn ở góc thẻ");
      modal(
        "Thao tác nhóm · " + ids.length + " máy",
        `<p>${ids.map((id) => devices.find((d) => d.id === id).name).join(", ")}</p><div class="row">${btn("bulk-enable", "check", "Bật nhận việc")}${btn("bulk-disable", "pause", "Tắt nhận việc")}</div><p class="muted smalltext" style="margin-top:15px">Điều khiển nhóm thực tế sẽ dùng chung khóa thao tác với automation.</p>`,
      );
      window.bulkDeviceIds = ids;
      break;
    }
    case "bulk-enable":
    case "bulk-disable":
      (window.bulkDeviceIds || []).forEach(
        (id) =>
          (devices.find((d) => d.id === id).enabled = a === "bulk-enable"),
      );
      closeModal();
      renderDevices();
      break;
    case "open-process":
      state.view = "process";
      closeModal();
      render();
      break;
    case "open-inspector":
      closeModal();
      openWorkflow(state.workflow);
      break;
    case "new-workflow":
      newWorkflow();
      break;
    case "new-workflow-confirm": {
      let name = $("#new-wf-name").value.trim();
      if (!name) return toast("Nhập tên workflow");
      let w = {
        id: uid("w"),
        app: $("#new-wf-app").value,
        name,
        version: 1,
        kind: $("#new-wf-kind").value,
      };
      state.workflows.push(w);
      state.graphs["wf:" + w.id] = {
        nodes: [
          node("start", "start", "Bắt đầu", 40, 80),
          node("end", "end", "Kết thúc", 350, 80),
        ],
        edges: [edge("start", "end")],
        groups: [],
      };
      closeModal();
      openWorkflow(w.id);
      break;
    }
    case "workflow-menu":
      workflowMenu();
      break;
    case "workflow-rename":
      wf().name = $("#wf-name").value.trim() || wf().name;
      closeModal();
      render();
      save();
      break;
    case "workflow-duplicate": {
      let w = { ...clone(wf()), id: uid("w"), name: wf().name + " · Bản sao" };
      state.workflows.push(w);
      state.graphs["wf:" + w.id] = clone(state.graphs.main);
      closeModal();
      openWorkflow(w.id);
      break;
    }
    case "publish-version": {
      let w = wf();
      state.versions = state.versions || [];
      state.versions.push({
        id: w.id,
        version: w.version,
        graphs: clone(state.graphs),
        inputs: clone(state.inputs),
        at: new Date().toISOString(),
      });
      w.version++;
      closeModal();
      render();
      save();
      toast("Đã tạo v" + w.version + " trong workspace xem trước");
      break;
    }
    case "workflow-delete":
      modal(
        "Lưu trữ workflow",
        `<p>Workflow <strong>${esc(wf().name)}</strong> sẽ được chuyển vào kho lưu trữ cục bộ và ẩn khỏi danh sách chọn.</p><div class="notice">Lịch sử và cấu hình được giữ. Bản desktop phải kiểm tra mọi tham chiếu trước khi xóa vĩnh viễn.</div>`,
        btn("modal-close", null, "Hủy") +
          btn("workflow-archive", "box", "Lưu trữ", "danger"),
      );
      break;
    case "workflow-archive": {
      if (state.workflows.length < 2)
        return toast("Cần giữ ít nhất một workflow trong bản xem trước");
      state.archived = state.archived || [];
      state.archived.push(clone(wf()));
      state.workflows = state.workflows.filter((w) => w.id !== state.workflow);
      let w = state.workflows[0];
      closeModal();
      openWorkflow(w.id);
      save();
      break;
    }
    case "export-workflow":
      exportWorkflow();
      break;
    case "import-workflow":
      $("#workflow-input").dataset.mode = "workflow";
      $("#workflow-input").click();
      break;
    case "folder":
      $("#folder-input").click();
      break;
    case "media":
      $("#media-input").click();
      break;
    case "import-data":
      importDataModal();
      break;
    case "pick-csv":
      $("#csv-input").click();
      break;
    case "export-csv":
      exportCSV();
      break;
    case "apply-import":
      for (let m of window.pendingImport || []) {
        let r = state.rows.find((r) => r.id === m.id);
        if (r && !r.status.includes("Đã đăng"))
          for (let k of ["caption", "hashtags", "comments", "affiliate"])
            if (k in m.data) r[k] = String(m.data[k]);
      }
      closeModal();
      saveContext();
      save();
      renderProcess();
      toast("Đã áp dụng dữ liệu khớp");
      break;
    case "demo-data":
      state.rows = demoRows();
      saveContext();
      save();
      renderProcess();
      toast("Đã nạp 6 dòng mẫu cho đối tượng hiện tại");
      break;
    case "add-row":
      state.rows.push({
        id: uid("content-"),
        file: "Nội dung mới",
        caption: "",
        hashtags: "",
        comments: "",
        affiliate: "",
        duration: "—",
        path: "Chưa chọn tệp",
        scheduled: "",
        status: "Chưa lên lịch",
        checked: false,
        files: 0,
      });
      renderProcess();
      saveContext();
      save();
      break;
    case "delete-rows": {
      let n = state.rows.filter((r) => r.checked).length;
      if (!n) return toast("Chọn dòng cần xóa");
      modal(
        "Xóa " + n + " dòng khỏi danh sách",
        `<p>Chỉ xóa dòng cấu hình trong bản HTML. Không xóa tệp nguồn, bài đã đăng hoặc dữ liệu trên điện thoại.</p>`,
        btn("modal-close", null, "Hủy") +
          btn("delete-rows-confirm", "trash", "Xóa dòng", "danger"),
      );
      break;
    }
    case "delete-rows-confirm":
      state.rows = state.rows.filter(
        (r) => !r.checked || r.status.includes("Đã đăng"),
      );
      closeModal();
      saveContext();
      save();
      renderProcess();
      break;
    case "bulk-edit": {
      let count = state.rows.filter((r) => r.checked).length;
      if (!count) return toast("Chọn dòng để sửa hàng loạt");
      modal(
        "Sửa hàng loạt · " + count + " dòng",
        `<div class="form-grid two"><div><label>Trường</label><select id="bulk-field"><option value="caption">Caption</option><option value="hashtags">Hashtag</option><option value="comments">Bình luận</option><option value="affiliate">Affiliate</option></select></div><div><label>Cách sửa</label><select id="bulk-mode"><option value="replace">Thay thế</option><option value="append">Nối cuối</option><option value="prepend">Chèn đầu</option></select></div><div class="full"><label>Nội dung</label><textarea id="bulk-value"></textarea></div></div>`,
        btn("modal-close", null, "Hủy") +
          btn("bulk-apply", "check", "Áp dụng", "primary"),
      );
      break;
    }
    case "bulk-apply": {
      let field = $("#bulk-field").value,
        mode = $("#bulk-mode").value,
        v = $("#bulk-value").value;
      state.rows
        .filter((r) => r.checked && !r.status.includes("Đã đăng"))
        .forEach(
          (r) =>
            (r[field] =
              mode === "replace"
                ? v
                : mode === "append"
                  ? r[field] + v
                  : v + r[field]),
        );
      closeModal();
      saveContext();
      save();
      renderRows();
      break;
    }
    case "schedule-preview":
      schedulePreview();
      break;
    case "schedule-apply":
      for (let p of window.pendingSchedule || []) {
        let r = state.rows.find((r) => r.id === p.id);
        if (r) {
          r.scheduled = p.next;
          r.status = "Đã lên lịch";
        }
      }
      closeModal();
      saveContext();
      save();
      renderProcess();
      toast("Đã cập nhật giờ đăng vào danh sách");
      break;
    case "process-save":
      saveContext();
      save();
      toast(
        "Đã lưu cấu hình riêng cho máy / app / workflow / account / đối tượng",
      );
      break;
    case "data-more":
      sourceOptions();
      break;
    case "source-save":
      state.settings.autoAppend = $("#source-append").checked;
      state.settings.dedupe = $("#source-dedupe").checked;
      state.settings.subfolders = $("#source-subfolders").checked;
      state.settings.watcher = $("#source-watcher").checked;
      closeModal();
      save();
      break;
    case "scan-accounts":
      modal(
        "Quét account & đối tượng",
        `<div class="notice">Quét thực tế cần Android đang đăng nhập. Ở bản HTML dùng danh sách mẫu.</div><table><tr><th>Account</th><th>Đối tượng</th></tr><tr><td>Minh Anh</td><td>Green Living · Daily Moments</td></tr><tr><td>Hoàng Nam</td><td>Travel Notes</td></tr></table><p class="muted smalltext" style="margin-top:12px">App không có fanpage sẽ hiển thị hồ sơ / đối tượng tương ứng. Không lưu mật khẩu hoặc 2FA.</p>`,
      );
      break;
    case "input-mapping":
      modal(
        "Ánh xạ dữ liệu vào workflow",
        `<table><thead><tr><th>Biến</th><th>Kiểu</th><th>Nguồn</th><th>Bắt buộc</th></tr></thead><tbody>${state.inputs.map((v) => `<tr><td>{{${v.scope === "row" ? "row" : "input"}.${esc(v.key)}}}</td><td>${v.type}</td><td>${v.scope === "row" ? "Cột danh sách nội dung" : v.scope === "output" ? "Kết quả chạy" : "Thiết lập tiến trình"}</td><td>${v.required ? "Có" : "Không"}</td></tr>`).join("")}</tbody></table>`,
        btn("inputs", "edit", "Sửa khai báo") +
          btn("modal-close", null, "Đóng"),
        true,
      );
      break;
    case "clone-process":
      modal(
        "Sao chép cấu hình tiến trình",
        `<div class="form-grid two"><div><label>Điện thoại đích</label><select id="clone-device">${devices.map((d) => `<option value="${d.id}">${d.name}</option>`).join("")}</select></div><div><label>Đối tượng đích</label><select id="clone-target"><option value="p1">Green Living</option><option value="p2">Daily Moments</option><option value="p3">Travel Notes</option></select></div></div><label class="checkbox-label"><input id="clone-data" type="checkbox" checked>Sao chép danh sách nội dung · đặt lại lịch và trạng thái</label>`,
        btn("modal-close", null, "Hủy") +
          btn("clone-confirm", "copy", "Sao chép", "primary"),
      );
      break;
    case "clone-confirm": {
      let rows = $("#clone-data").checked
          ? clone(state.rows).map((r) => ({
              ...r,
              scheduled: "",
              status: "Chưa lên lịch",
              checked: false,
            }))
          : [],
        device = $("#clone-device").value,
        target = $("#clone-target").value;
      saveContext();
      state.device = device;
      state.target = target;
      state.account = target === "p3" ? "a2" : "a1";
      state.rows = rows;
      closeModal();
      saveContext();
      save();
      renderProcess();
      break;
    }
    case "process-options":
      modal(
        "Chính sách tiến trình",
        `<div class="form-grid two"><div><label>Khi điện thoại bận</label><select><option>Xếp hàng · không chạy chen</option></select></div><div><label>Khi hết nội dung</label><select><option>Dừng, chờ nội dung mới</option></select></div><div><label>Chống trùng</label><select><option>Nội dung + app + target · toàn workspace</option></select></div><div><label>Lỗi bình luận</label><select><option>Chỉ xử lý bình luận · không đăng lại bài</option></select></div></div><div class="notice">Chính sách đã chốt. Bản HTML không thực thi scheduler hoặc các khóa giao dịch.</div>`,
      );
      break;
    case "queue":
      modal(
        "Hàng đợi của cấu hình hiện tại",
        `<table><thead><tr><th>Nội dung</th><th>Lịch dự kiến</th><th>Trạng thái</th></tr></thead><tbody>${
          state.rows
            .filter((r) => r.scheduled)
            .map(
              (r) =>
                `<tr><td>${esc(r.file)}</td><td>${dateVN(r.scheduled)}</td><td>${r.status}</td></tr>`,
            )
            .join("") ||
          '<tr><td colspan="3">Chưa có lịch. Vào Tiến trình để lên lịch.</td></tr>'
        }</tbody></table><p class="muted smalltext" style="margin-top:12px">HTML không tự chạy hàng đợi. Bản desktop sẽ xử lý theo giờ đến hạn, độ ưu tiên và thứ tự tạo.</p>`,
      );
      break;
    case "reconcile":
      modal(
        "Đối soát kết quả chưa rõ",
        `<div class="notice">Đây là thiết kế màn hình đối soát. Chưa có giao dịch đăng thật trong bản HTML.</div><div class="form-grid two"><div><label>Kết luận sau kiểm tra</label><select><option>Đã tìm thấy đúng bài</option><option>Xác nhận chưa đăng</option><option>Chưa đủ bằng chứng</option></select></div><div><label>Liên kết / mã bài xác minh</label><input placeholder="URL / post ID"></div><div class="full"><label>Ghi chú bằng chứng</label><textarea placeholder="Tài khoản, thời điểm, nội dung khớp…"></textarea></div></div><p class="muted smalltext">Kết luận chưa đăng không tự kích hoạt đăng lại. Gửi bình luận chưa rõ cũng phải đối soát trước khi thử lại.</p>`,
      );
      break;
    case "export-logs":
      download("AutoReels-preview-logs.json", {
        logs: state.logs,
        history: state.history,
      });
      break;
    case "theme":
      state.settings.theme =
        state.settings.theme === "light" ? "dark" : "light";
      document.body.classList.toggle("dark", state.settings.theme === "dark");
      save();
      break;
    case "settings":
      settings();
      break;
    case "settings-save":
      state.settings.theme = $("#set-theme").value;
      state.settings.overdue = $("#set-overdue").value;
      document.body.classList.toggle("dark", state.settings.theme === "dark");
      closeModal();
      save();
      break;
    case "export-workspace":
      saveContext();
      download("AutoReels-workspace-preview.json", {
        format: "autoreels-preview-workspace-v1",
        state,
      });
      break;
    case "restore-workspace":
      $("#workflow-input").dataset.mode = "workspace";
      $("#workflow-input").click();
      break;
    case "reset-preview":
      modal(
        "Đặt lại bản xem trước",
        `<p>Bản nháp cục bộ sẽ được đặt lại. Bạn có thể xuất workspace trước để giữ các chỉnh sửa.</p>`,
        btn("export-workspace", "download", "Xuất trước") +
          btn("reset-confirm", "refresh", "Đặt lại", "danger"),
      );
      break;
    case "reset-confirm":
      try {
        localStorage.removeItem("autoreels-studio-preview-v1");
      } catch {}
      location.reload();
      break;
    case "help":
      help();
      break;
    case "coverage":
      coverageModal();
      break;
    case "notifications":
      modal(
        "Thông báo",
        `<div class="activity-item">${ic("check")}<div><strong>Workspace xem trước đã sẵn sàng</strong><p class="muted smalltext">Thử canvas, dữ liệu và lịch ngay trong trình duyệt.</p></div></div><div class="activity-item">${ic("phone")}<div><strong>Chưa kết nối điện thoại thật</strong><p class="muted smalltext">Các khung hình và kết quả chạy được gắn nhãn mẫu.</p></div></div><div class="activity-item">${ic("save")}<div><strong>Lưu bản nháp</strong><p class="muted smalltext">Dùng Xuất workspace để giữ toàn bộ cấu hình thành tệp.</p></div></div>`,
      );
      break;
    default:
      toast("Thao tác chưa xác định: " + a);
  }
}
document.addEventListener("click", (e) => {
  const target = e.target;
  let b = target.closest("[data-view]");
  if (b) {
    stopRun(false);
    state.view = b.dataset.view;
    render();
    save();
    return;
  }
  b = target.closest("[data-action]");
  if (b) {
    let a = b.dataset.action;
    $("#context").innerHTML = "";
    action(a, b);
    return;
  }
  if (!target.closest(".context-menu")) $("#context").innerHTML = "";
  b = target.closest("[data-add]");
  if (b) {
    addNode(b.dataset.add);
    return;
  }
  b = target.closest("[data-sub-add]");
  if (b) {
    addNode("subflow", undefined, undefined, b.dataset.subAdd);
    return;
  }
  b = target.closest("[data-lib]");
  if (b) {
    state.libraryTab = b.dataset.lib;
    $$("[data-lib]").forEach((x) => x.classList.toggle("active", x === b));
    renderLibrary();
    return;
  }
  b = target.closest("[data-bottom]");
  if (b) {
    state.bottomTab = b.dataset.bottom;
    renderBottom();
    return;
  }
  b = target.closest("[data-tree]");
  if (b) {
    phonePick();
    return;
  }
  b = target.closest("#phone-screen");
  if (b) {
    phonePick();
    return;
  }
  b = target.closest("[data-device-setup]");
  if (b) {
    state.device = b.dataset.deviceSetup;
    state.view = "process";
    render();
    return;
  }
  b = target.closest("[data-device-inspector]");
  if (b) {
    state.testDevice = b.dataset.deviceInspector;
    state.view = "inspector";
    render();
    fit();
    return;
  }
  b = target.closest("[data-device-card]");
  if (b && !target.closest("input,button")) {
    state.device = b.dataset.deviceCard;
    renderDevices();
    return;
  }
  b = target.closest("[data-setup-device]");
  if (b) {
    switchContext({ device: b.dataset.setupDevice });
    return;
  }
  b = target.closest("[data-library-app]");
  if (b) {
    state.app = b.dataset.libraryApp;
    renderWorkflows();
    return;
  }
  b = target.closest("[data-open-wf]");
  if (b) {
    openWorkflow(b.dataset.openWf);
    return;
  }
  b = target.closest("[data-wf-menu]");
  if (b) {
    workflowMenu(b.dataset.wfMenu);
    return;
  }
  b = target.closest("[data-day]");
  if (b) {
    let n = +b.dataset.day;
    state.weekdays = state.weekdays.includes(n)
      ? state.weekdays.filter((d) => d !== n)
      : [...state.weekdays, n];
    b.classList.toggle("active");
    save();
    return;
  }
  b = target.closest("[data-modal-add]");
  if (b) {
    let ed = window.edgeToInsert
        ? graph().edges.find((e) => e.id === window.edgeToInsert)
        : null,
      n = addNode(b.dataset.modalAdd);
    if (ed) {
      graph().edges = graph().edges.filter((e) => e.id !== ed.id);
      graph().edges.push(edge(ed.a, n.id, ed.port), edge(n.id, ed.b));
      window.edgeToInsert = null;
      renderGraph();
      save();
    }
    closeModal();
    return;
  }
  b = target.closest("[data-input-delete]");
  if (b) {
    state.inputs = readInputForm();
    state.inputs.splice(+b.dataset.inputDelete, 1);
    $("#input-rows").innerHTML = inputRows();
    return;
  }
  b = target.closest("[data-row-more]");
  if (b) {
    let r = state.rows.find((r) => r.id === b.dataset.rowMore);
    modal(
      "Chi tiết nội dung · " + r.file,
      `<div class="form-grid two"><div><label>ID ổn định</label><input value="${esc(r.id)}" readonly></div><div><label>Số tệp</label><input value="${r.files || 1}" readonly></div><div class="full"><label>Nơi lưu trữ</label><input value="${esc(r.path + r.file)}" readonly></div><div><label>Lịch</label><input value="${dateVN(r.scheduled)}" readonly></div><div><label>Trạng thái</label><input value="${esc(r.status)}" readonly></div></div><div class="notice">Tệp thật được chuyển từng lượt ở bản desktop. Đổi nguồn sau khi tạo job cần đối chiếu lại trước khi chạy.</div>`,
    );
    return;
  }
});
document.addEventListener("change", (e) => {
  if (e.target.matches("#test-device")) {
    stopRun(false);
    state.testDevice = e.target.value;
    renderInspector();
    save();
    toast("Đã đổi máy kiểm thử. Workflow giữ nguyên.");
  }
  if (e.target.matches("[data-device-enable]")) {
    devices.find((d) => d.id === e.target.dataset.deviceEnable).enabled =
      e.target.checked;
    toast(
      e.target.checked
        ? "Đã bật nhận việc trong cấu hình mẫu"
        : "Đã tắt nhận việc trong cấu hình mẫu",
    );
  }
});
document.addEventListener("input", (e) => {
  if (e.target.id === "phone-zoom") {
    let z = +e.target.value / 100;
    $("#phone-screen").style.transform = `scale(${z})`;
    $("#phone-screen").style.transformOrigin = "top center";
    $("#phone-zoom-value").textContent = e.target.value + "%";
  }
});
document.addEventListener("keydown", (e) => {
  let typing = e.target.closest("input,textarea,select,[contenteditable]");
  if (e.key === "Escape") {
    closeModal();
    $("#context").innerHTML = "";
    connecting = null;
    renderGraph();
    return;
  }
  if (typing) return;
  if (e.code === "Space") {
    spaceHeld = true;
    e.preventDefault();
  }
  if (state.view !== "inspector") return;
  let ctrl = e.ctrlKey || e.metaKey;
  if (
    ctrl &&
    ["s", "z", "y", "c", "v", "d", "a", "f", "0"].includes(e.key.toLowerCase())
  ) {
    e.preventDefault();
    switch (e.key.toLowerCase()) {
      case "s":
        save();
        break;
      case "z":
        e.shiftKey ? redo() : undo();
        break;
      case "y":
        redo();
        break;
      case "c":
        action("copy");
        break;
      case "v":
        pasteNodes();
        break;
      case "d":
        duplicateSelected();
        break;
      case "a":
        action("select-all");
        break;
      case "f":
        $("#node-search")?.focus();
        break;
      case "0":
        fit();
        break;
    }
  }
  if (e.key === "Delete" || e.key === "Backspace") {
    e.preventDefault();
    removeSelected();
  }
  if (e.key === "F2") {
    e.preventDefault();
    action("rename-node");
  }
});
document.addEventListener("keyup", (e) => {
  if (e.code === "Space") spaceHeld = false;
});
$("#folder-input").onchange = (e) => {
  addFiles(e.target.files);
  e.target.value = "";
};
$("#media-input").onchange = (e) => {
  addFiles(e.target.files);
  e.target.value = "";
};
$("#csv-input").onchange = (e) => {
  if (e.target.files[0]) importDataFile(e.target.files[0]);
  e.target.value = "";
};
$("#workflow-input").onchange = async (e) => {
  let f = e.target.files[0];
  if (!f) return;
  try {
    let data = JSON.parse(await f.text());
    if (e.target.dataset.mode === "workspace") {
      if (
        data.format !== "autoreels-preview-workspace-v1" ||
        !data.state?.graphs
      )
        throw Error("Không đúng cấu trúc workspace");
      stopRun(false);
      state = data.state;
      state.selected = [];
      state.edgeSelected = null;
      closeModal();
      document.body.classList.toggle("dark", state.settings.theme === "dark");
      render();
      save();
      toast("Đã khôi phục workspace");
    } else {
      if (
        data.format !== "autoreels-preview-workflow-v1" ||
        !data.graphs?.main ||
        !data.workflow
      )
        throw Error("Không đúng cấu trúc workflow");
      let id = uid("w");
      state.workflows.push({
        ...data.workflow,
        id,
        name: data.workflow.name + " · Nhập",
      });
      state.graphs["wf:" + id] = clone(data.graphs.main);
      for (let [k, g] of Object.entries(data.graphs))
        if (k !== "main" && !k.startsWith("wf:") && !state.graphs[k])
          state.graphs[k] = g;
      openWorkflow(id);
      toast("Đã nhập workflow");
    }
  } catch (err) {
    toast("Không nhập được: " + err.message);
  }
  e.target.value = "";
};
window.addEventListener("beforeunload", () => {
  try {
    localStorage.setItem("autoreels-studio-preview-v1", JSON.stringify(state));
  } catch {}
});

// Extra canvas gestures use capture so they do not start a node drag.
document.addEventListener(
  "pointerdown",
  (e) => {
    let size = e.target.closest("[data-size]"),
      rer = e.target.closest("[data-reroute]");
    if (size) {
      e.stopPropagation();
      e.preventDefault();
      checkpoint();
      let n = graph().nodes.find((n) => n.id === size.dataset.size),
        sx = e.clientX,
        sy = e.clientY,
        w = n.w || 190,
        h = n.h || 112;
      let move = (ev) => {
        n.w = Math.max(180, w + (ev.clientX - sx) / state.zoom);
        n.h = Math.max(112, h + (ev.clientY - sy) / state.zoom);
        renderGraph();
      };
      window.addEventListener("pointermove", move);
      window.addEventListener(
        "pointerup",
        () => {
          window.removeEventListener("pointermove", move);
          save();
        },
        { once: true },
      );
    }
    if (rer) {
      e.stopPropagation();
      e.preventDefault();
      checkpoint();
      let ed = graph().edges.find((ed) => ed.id === rer.dataset.reroute),
        rect = $("#canvas").getBoundingClientRect();
      let move = (ev) => {
        ed.reroute = {
          x: (ev.clientX - rect.left - state.pan.x) / state.zoom,
          y: (ev.clientY - rect.top - state.pan.y) / state.zoom,
        };
        renderGraph();
      };
      window.addEventListener("pointermove", move);
      window.addEventListener(
        "pointerup",
        () => {
          window.removeEventListener("pointermove", move);
          save();
        },
        { once: true },
      );
    }
  },
  true,
);
document.addEventListener("click", (e) => {
  let b = e.target.closest("[data-toggle-group]");
  if (b) {
    checkpoint();
    let g = graph().groups.find((g) => g.id === b.dataset.toggleGroup);
    g.collapsed = !g.collapsed;
    renderGraph();
    save();
  }
});

// A workflow owns its complete graph set and input schema. App-specific edits never leak.
function rememberDefinition() {
  state.workflowBundles = state.workflowBundles || {};
  state.workflowBundles[state.workflow] = {
    graphs: clone(
      Object.fromEntries(
        Object.entries(state.graphs).filter(([k]) => !k.startsWith("wf:")),
      ),
    ),
    inputs: clone(state.inputs),
  };
}
function getDefinition(id) {
  if (state.workflowBundles?.[id]) return clone(state.workflowBundles[id]);
  let w = state.workflows.find((w) => w.id === id),
    g = {
      main: state.graphs["wf:" + id]
        ? clone(state.graphs["wf:" + id])
        : mainGraph(w.app),
      account: makeSub("account"),
      page: makeSub("page"),
      compose: makeSub("compose"),
      comment: makeSub("comment"),
    };
  let fields = [
    { key: "video", type: "file", scope: "row", required: true },
    { key: "caption", type: "text", scope: "row", required: true },
    { key: "hashtags", type: "text", scope: "row", required: false },
    { key: "comments", type: "list", scope: "row", required: false },
    { key: "affiliate", type: "url", scope: "row", required: false },
    { key: "accountId", type: "identity", scope: "process", required: true },
    { key: "targetId", type: "identity", scope: "process", required: true },
  ];
  if (w.app !== "fb" && w.app !== "lite") {
    for (let n of g.page.nodes) n.name = n.name.replaceAll("fanpage", "hồ sơ");
    let n = g.compose.nodes.find((n) => n.id === "s2");
    if (n)
      n.name =
        w.app === "ig"
          ? "Mở nút tạo trên Instagram"
          : w.app === "tt"
            ? "Mở trình tạo TikTok"
            : "Mở soạn bài Threads";
    let n3 = g.compose.nodes.find((n) => n.id === "s3");
    if (n3)
      n3.name =
        w.app === "ig"
          ? "Chọn loại Reel / video"
          : w.app === "tt"
            ? "Mở nguồn tải nội dung"
            : "Chọn tệp đính kèm";
    for (let n of [
      ...g.main.nodes,
      ...g.compose.nodes,
      ...g.account.nodes,
      ...g.page.nodes,
      ...g.comment.nodes,
    ]) {
      n.selector = "";
      if (n.type === "tap")
        n.description =
          "Chọn phần tử trên app " +
          apps.find((a) => a.id === w.app).name +
          " khi kiểm thử";
    }
  }
  if (w.id === "w2") {
    fields[0] = { key: "images", type: "file[]", scope: "row", required: true };
    for (let n of [...g.main.nodes, ...g.compose.nodes]) {
      n.name = n.name.replaceAll("video", "ảnh");
      n.value = n.value.replaceAll("row.video", "row.images");
    }
  }
  if (w.app === "th") {
    fields = fields.filter((f) => f.key !== "video");
    g.main.nodes = g.main.nodes.filter((n) => !["n2", "n12"].includes(n.id));
    g.main.edges = g.main.edges.filter(
      (e) => !["n2", "n12"].includes(e.a) && !["n2", "n12"].includes(e.b),
    );
    g.main.edges.push(
      edge("n1", "n3"),
      edge("n10", "n13", "false"),
      edge("n11", "n13"),
    );
    g.compose.nodes = g.compose.nodes.filter(
      (n) => !["s3", "s4", "s5"].includes(n.id),
    );
    g.compose.edges = g.compose.edges.filter(
      (e) =>
        !["s3", "s4", "s5"].includes(e.a) && !["s3", "s4", "s5"].includes(e.b),
    );
    g.compose.edges.push(edge("s2", "s6"));
  }
  return { graphs: g, inputs: fields };
}
const originalOpenWorkflow = openWorkflow;
openWorkflow = function (id) {
  if (id === state.workflow) {
    originalOpenWorkflow(id);
    return;
  }
  rememberDefinition();
  const bundle = getDefinition(id);
  originalOpenWorkflow(id);
  state.graphs = bundle.graphs;
  state.inputs = bundle.inputs;
  state.graphKey = "main";
  render();
  fit();
  save();
};
const originalSwitchContext = switchContext;
switchContext = function (changes) {
  let bundle;
  if (changes.workflow && changes.workflow !== state.workflow) {
    rememberDefinition();
    bundle = getDefinition(changes.workflow);
  }
  originalSwitchContext(changes);
  if (bundle) {
    state.graphs = bundle.graphs;
    state.inputs = bundle.inputs;
    state.graphKey = "main";
    render();
    save();
  }
};
function dynamicColumns() {
  if (!$("#content-table")) return;
  $$("[data-extra-header]").forEach((e) => e.remove());
  const media = state.inputs.some(
      (f) => f.scope === "row" && ["file", "file[]"].includes(f.type),
    ),
    keys = new Set(
      state.inputs.filter((f) => f.scope === "row").map((f) => f.key),
    );
  const mapping = {
    3: "caption",
    4: "hashtags",
    6: "comments",
    7: "affiliate",
  };
  const trs = $$("#content-table tr");
  trs.forEach((tr) => {
    for (let [idx, k] of Object.entries(mapping))
      if (tr.children[+idx])
        tr.children[+idx].style.display = keys.has(k) ? "" : "none";
    [5, 8].forEach((i) => {
      if (tr.children[i]) tr.children[i].style.display = media ? "" : "none";
    });
  });
  $$('[data-action="folder"],[data-action="media"]').forEach(
    (b) => (b.style.display = media ? "" : "none"),
  );
  const extras = state.inputs.filter(
    (f) =>
      f.scope === "row" &&
      ![
        "video",
        "images",
        "caption",
        "hashtags",
        "comments",
        "affiliate",
      ].includes(f.key),
  );
  if (!extras.length) return;
  let head = $("#content-table thead tr");
  for (let f of extras) {
    let th = document.createElement("th");
    th.dataset.extraHeader = f.key;
    th.textContent = f.key + (f.required ? " *" : "");
    head.insertBefore(th, head.lastElementChild);
  }
  $$("#content-rows tr[data-row]").forEach((tr) => {
    let r = state.rows.find((r) => r.id === tr.dataset.row);
    for (let f of extras) {
      let td = document.createElement("td"),
        inp = document.createElement("input");
      inp.type =
        f.type === "number"
          ? "number"
          : f.type === "boolean"
            ? "checkbox"
            : "text";
      inp.value = r[f.key] ?? "";
      if (f.type === "boolean") inp.checked = !!r[f.key];
      inp.placeholder = f.type;
      inp.onchange = () => {
        r[f.key] =
          f.type === "boolean"
            ? inp.checked
            : f.type === "number"
              ? +inp.value
              : inp.value;
        saveContext();
        save();
      };
      td.append(inp);
      tr.insertBefore(td, tr.lastElementChild);
    }
  });
}
const originalRenderRows = renderRows;
renderRows = function () {
  originalRenderRows();
  dynamicColumns();
};
// Extra process fields declared by workflows remain configurable outside row data.
const originalRenderProcess = renderProcess;
renderProcess = function () {
  originalRenderProcess();
  let extras = state.inputs.filter(
    (f) => f.scope === "process" && !["accountId", "targetId"].includes(f.key),
  );
  if (!extras.length) return;
  state.processFields = state.processFields || {};
  let host = $(".setup-grid"),
    box = document.createElement("div");
  box.className = "full";
  box.style.gridColumn = "1/-1";
  box.innerHTML =
    '<div class="form-grid">' +
    extras
      .map(
        (f) =>
          `<div><label>${esc(f.key)} ${f.required ? "*" : ""}</label><input data-process-extra="${esc(f.key)}" value="${esc(state.processFields[contextKey()]?.[f.key] || "")}" placeholder="${esc(f.type)}"></div>`,
      )
      .join("") +
    "</div>";
  host.append(box);
  $$("[data-process-extra]").forEach(
    (e) =>
      (e.onchange = () => {
        state.processFields[contextKey()] =
          state.processFields[contextKey()] || {};
        state.processFields[contextKey()][e.dataset.processExtra] = e.value;
        save();
      }),
  );
};
render();
if (state.view === "inspector") setTimeout(fit, 80);
